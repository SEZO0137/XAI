#!/usr/bin/env python3
"""
test_ui.py  —  Word AI  |  Live Tester
=======================================
Python 3.12 · scikit-learn · matplotlib

Usage
-----
1. Click  "Load Model (.pkl)"  and select  recordings/model.pkl
2. Hold  R  →  records exactly 1 second.
3. Release  R  →  predicted class name appears + pie chart updates.
4. Use  "+"  to add extra classes to the display.
"""

import json
import math
import queue
import threading
import time
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.patches as mpatches
import numpy as np
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
from sklearn.pipeline import Pipeline

try:
    import sounddevice as sd
    _HAS_AUDIO = True
except ImportError:
    _HAS_AUDIO = False
    print("[test_ui] WARNING: sounddevice not installed.")


# ── BGN class constant (must match recorder_ui.py) ───────────────────────────
BGN_CID  = 0
BGN_NAME = "BGN"

# ── Paths ──────────────────────────────────────────────────────────────────────
ROOT         = Path(__file__).resolve().parent
WEIGHTS_JSON = ROOT / "model_weights.json"   # written by recorder_ui.py


# ── Audio constants ────────────────────────────────────────────────────────────
SR        = 16_000
DURATION  = 1.0
N_FFT     = 256
HOP       = 128
N_MELS    = 26
N_MFCC    = 13
INPUT_DIM = N_MFCC * 2


# ── Default vocabulary ─────────────────────────────────────────────────────────
DEFAULT_VOCAB: dict[int, str] = {
     1: "yes",    2: "no",     3: "hello",  4: "bye",    5: "I",
     6: "you",    7: "want",   8: "need",   9: "help",  10: "what",
    11: "how",   12: "where", 13: "when",  14: "good",  15: "bad",
    16: "please",17: "thank", 18: "stop",  19: "go",    20: "here",
    21: "there", 22: "more",  23: "less",  24: "up",    25: "down",
    26: "left",  27: "right", 28: "on",    29: "off",   30: "okay",
}

_PAL = [
    "#1f77b4","#aec7e8","#ff7f0e","#ffbb78","#2ca02c",
    "#98df8a","#d62728","#ff9896","#9467bd","#c5b0d5",
    "#8c564b","#c49c94","#e377c2","#f7b6d2","#7f7f7f",
    "#c7c7c7","#bcbd22","#dbdb8d","#17becf","#9edae5",
    "#393b79","#637939","#8c6d31","#843c39","#7b4173",
    "#3182bd","#e6550d","#31a354","#756bb1","#636363",
]


# ── MFCC (identical to recorder_ui.py) ────────────────────────────────────────
def _mel_fb():
    n_bins  = N_FFT // 2 + 1
    m_lo    = 2595.0 * math.log10(1.0 + 0.0      / 700.0)
    m_hi    = 2595.0 * math.log10(1.0 + SR / 2.0 / 700.0)
    mel_pts = np.linspace(m_lo, m_hi, N_MELS + 2)
    hz_pts  = 700.0 * (10.0 ** (mel_pts / 2595.0) - 1.0)
    bins    = np.floor((N_FFT + 1) * hz_pts / SR).astype(int)
    fb      = np.zeros((N_MELS, n_bins), dtype=np.float32)
    for m in range(1, N_MELS + 1):
        lo, c, hi = bins[m-1], bins[m], bins[m+1]
        for k in range(lo, c):  fb[m-1, k] = (k-lo)/(c-lo)  if c!=lo  else 0.0
        for k in range(c,  hi): fb[m-1, k] = (hi-k)/(hi-c)  if hi!=c  else 0.0
    return fb

def _dct_mat():
    d = np.zeros((N_MFCC, N_MELS), dtype=np.float32)
    for i in range(N_MFCC):
        for j in range(N_MELS):
            d[i, j] = math.cos(math.pi * i * (j + 0.5) / N_MELS)
    d[0] *= math.sqrt(1.0 / N_MELS)
    for i in range(1, N_MFCC): d[i] *= math.sqrt(2.0 / N_MELS)
    return d

_HAMMING = np.array([0.54 - 0.46 * math.cos(2*math.pi*n/(N_FFT-1))
                     for n in range(N_FFT)], dtype=np.float32)
_MEL_FB  = _mel_fb()
_DCT_MAT = _dct_mat()

def extract_features(audio: np.ndarray) -> np.ndarray:
    n_frames = max(1, (len(audio) - N_FFT) // HOP + 1)
    acc = np.zeros((N_MFCC, n_frames), dtype=np.float32)
    for f in range(n_frames):
        seg = audio[f*HOP : f*HOP+N_FFT]
        if len(seg) < N_FFT: seg = np.pad(seg, (0, N_FFT-len(seg)))
        spec = np.fft.rfft(seg.astype(np.float32) * _HAMMING)
        pwr  = (np.abs(spec)**2) / N_FFT
        acc[:, f] = _DCT_MAT @ np.log(np.maximum(_MEL_FB @ pwr, 1e-10))
    return np.concatenate([acc.mean(1), acc.std(1)]).astype(np.float32)


# ══════════════════════════════════════════════════════════════════════════════
class TestApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root      = root
        self.classes:  dict[int, str]  = dict(DEFAULT_VOCAB)
        self.pipeline: Pipeline | None = None
        self.cid_list: list[int]       = []   # order from training
        self.recording: bool           = False
        self.r_held:    bool           = False
        self.q: queue.Queue            = queue.Queue()

        self._build_ui()
        self._bind_keys()
        self._poll()
        self._redraw_chart(None, None)

    # ── Queue poll ─────────────────────────────────────────────────────────────
    def _poll(self) -> None:
        try:
            while True:
                tag, val = self.q.get_nowait()
                if tag == "rec_progress":
                    self.prog.config(value=float(val))
                elif tag == "rec_done":
                    self._rec_done_ui()
                elif tag == "inference":
                    probs, cid_list = val
                    self._show_result(probs, cid_list)
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    # ── UI ─────────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        self.root.title("Word AI — Tester")
        self.root.minsize(580, 840)

        tk.Label(self.root, text="Word AI — Live Tester",
                 font=("Helvetica", 15, "bold"), fg="#1a1a2e").pack(padx=8, pady=4)

        # Model loader
        mf = tk.Frame(self.root)
        mf.pack(fill="x", padx=10, pady=2)
        tk.Button(mf, text="Load Model (.pkl) …",
                  bg="#8e44ad", fg="white", relief="flat",
                  command=self._load_model).pack(side="left", padx=4)
        self.lbl_model = tk.Label(mf, text="No model loaded", fg="gray",
                                   font=("Helvetica", 10))
        self.lbl_model.pack(side="left", padx=6)

        # Add class
        top = tk.LabelFrame(self.root, text=" Manage Classes ", padx=8, pady=6)
        top.pack(fill="x", padx=10, pady=4)
        tk.Label(top, text="Name:").grid(row=0, column=0, sticky="e")
        self.ent_name = tk.Entry(top, width=14)
        self.ent_name.grid(row=0, column=1, padx=4)
        tk.Label(top, text="ID:").grid(row=0, column=2, sticky="e")
        self.ent_id = tk.Entry(top, width=7)
        self.ent_id.grid(row=0, column=3, padx=4)
        tk.Button(top, text="  +  ", font=("Helvetica", 12, "bold"),
                  bg="#27ae60", fg="white", relief="flat",
                  command=self._add_class).grid(row=0, column=4, padx=6)

        # Prediction display
        self.lbl_pred = tk.Label(self.root, text="—",
                                  font=("Helvetica", 32, "bold"), fg="#e74c3c")
        self.lbl_pred.pack(pady=6)
        self.lbl_conf = tk.Label(self.root,
                                  text="Hold  R  to record  ·  Confidence: —",
                                  font=("Helvetica", 11), fg="#555")
        self.lbl_conf.pack()

        # Pie chart
        cf = tk.Frame(self.root, bd=1, relief="sunken")
        cf.pack(fill="both", expand=True, padx=10, pady=4)
        self.fig    = Figure(figsize=(5.2, 3.8), dpi=92, facecolor="#f8f9fa")
        self.ax     = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=cf)
        self.canvas.get_tk_widget().pack(fill="both", expand=True)

        # Record bar
        rec = tk.LabelFrame(self.root, text=" Record ", padx=8, pady=6)
        rec.pack(fill="x", padx=10, pady=4)
        self.lbl_status = tk.Label(rec, text="Hold  R  to record (1 second)",
                                    fg="#7f8c8d", font=("Helvetica", 10))
        self.lbl_status.pack()
        self.prog = ttk.Progressbar(rec, length=510, mode="determinate")
        self.prog.pack(pady=3)

    def _bind_keys(self) -> None:
        self.root.bind("<KeyPress-r>",   self._on_r_press)
        self.root.bind("<KeyRelease-r>", self._on_r_release)
        self.root.focus_set()

    # ── Model loading ──────────────────────────────────────────────────────────
    def _load_model(self) -> None:
        path = filedialog.askopenfilename(
            title="Select trained sklearn Pipeline (.pkl)",
            filetypes=[("Joblib pickle", "*.pkl"), ("All files", "*.*")])
        if not path:
            return
        try:
            self.pipeline = joblib.load(path)
        except Exception as e:
            messagebox.showerror("Load Error", str(e))
            return

        self.lbl_model.config(text=Path(path).name, fg="#27ae60")

        # Load class metadata
        candidates = [Path(path).parent / "model_weights.json", WEIGHTS_JSON]
        for mp in candidates:
            if mp.exists():
                try:
                    meta = json.loads(mp.read_text(encoding="utf-8"))
                    cl   = [int(c) for c in meta.get("cid_list", [])]
                    names = {int(k): v for k, v in meta.get("classes", {}).items()}
                    if cl and names:
                        self.cid_list = cl
                        self.classes.update(names)
                        print(f"[test_ui] Loaded {len(cl)} classes from {mp.name}")
                except Exception:
                    pass
                break

        self._redraw_chart(None, None)

    # ── Add class ──────────────────────────────────────────────────────────────
    def _add_class(self) -> None:
        name = self.ent_name.get().strip()
        raw  = self.ent_id.get().strip()
        if not name:
            return
        try:
            cid = int(raw)
        except ValueError:
            messagebox.showerror("Error", "ID must be integer.")
            return
        self.classes[cid] = name
        self._redraw_chart(None, None)
        self.ent_name.delete(0, tk.END)
        self.ent_id.delete(0, tk.END)

    # ── Recording ──────────────────────────────────────────────────────────────
    def _on_r_press(self, _event) -> None:
        if self.r_held or self.recording:
            return
        if self.pipeline is None:
            self.lbl_status.config(text="⚠  Load a model first!", fg="red")
            return
        if not _HAS_AUDIO:
            self.lbl_status.config(text="⚠  sounddevice not installed!", fg="red")
            return
        self.r_held    = True
        self.recording = True
        self.lbl_status.config(text="●  RECORDING …", fg="red")
        threading.Thread(target=self._rec_worker, daemon=True).start()

    def _on_r_release(self, _event) -> None:
        self.r_held = False

    def _rec_worker(self) -> None:
        steps = 50
        try:
            audio = sd.rec(int(SR * DURATION),
                           samplerate=SR, channels=1, dtype="float32")
            for i in range(steps + 1):
                self.q.put(("rec_progress", str(i / steps * 100)))
                time.sleep(DURATION / steps)
            sd.wait()
            flat  = audio.flatten().astype(np.float32)
            feat  = extract_features(flat).reshape(1, -1)
            probs = self.pipeline.predict_proba(feat)[0].tolist()
            self.q.put(("inference", (probs, list(self.cid_list))))
        except Exception as e:
            print(f"[test_ui] Error during inference: {e}")
        finally:
            self.q.put(("rec_done", ""))

    def _rec_done_ui(self) -> None:
        self.recording = False
        self.prog.config(value=0)
        self.lbl_status.config(text="Hold  R  to record (1 second)", fg="#7f8c8d")

    # ── Result display ─────────────────────────────────────────────────────────
    def _show_result(self, probs: list[float], cid_list: list[int]) -> None:
        n = len(probs)
        if not cid_list or len(cid_list) != n:
            cid_list = sorted(self.classes.keys())[:n]

        best_i    = int(np.argmax(probs))
        best_cid  = cid_list[best_i] if best_i < len(cid_list) else -1
        best_name = self.classes.get(best_cid, str(best_cid))
        conf      = probs[best_i] * 100.0

        self.lbl_pred.config(text=best_name, fg="#e74c3c")
        self.lbl_conf.config(
            text=f"Confidence: {conf:.1f}%  ·  ID: {best_cid}")
        self._redraw_chart(probs, cid_list)

    # ── Pie chart ──────────────────────────────────────────────────────────────
    def _redraw_chart(self,
                      probs:    list[float] | None,
                      cid_list: list[int]   | None) -> None:
        self.ax.clear()

        if cid_list and probs and len(cid_list) == len(probs):
            ids = cid_list
        else:
            ids = sorted(self.classes.keys())

        labels  = [self.classes.get(c, str(c)) for c in ids]
        n       = max(len(labels), 1)
        sizes   = [max(p, 1e-6) for p in probs] if (probs and len(probs)==n) \
                  else [1.0/n]*n
        colors  = [_PAL[i % len(_PAL)] for i in range(n)]
        explode = [0.0] * n
        if probs and len(probs) == n:
            explode[int(np.argmax(probs))] = 0.07

        self.ax.pie(sizes, colors=colors, startangle=90, explode=explode,
                    wedgeprops={"width": 0.55, "edgecolor": "white", "linewidth": 1.2})

        if probs and len(probs) == n:
            winner = labels[int(np.argmax(probs))]
            pct    = max(probs) * 100.0
            self.ax.set_title(f"{winner}  ({pct:.1f}%)",
                              fontsize=12, fontweight="bold", pad=8)
        else:
            self.ax.set_title("Record to predict", fontsize=10, pad=6)

        patches = [mpatches.Patch(color=colors[i], label=labels[i])
                   for i in range(n)]
        self.ax.legend(handles=patches, loc="center left",
                       bbox_to_anchor=(1.02, 0.5),
                       fontsize=7, ncol=2 if n > 12 else 1, framealpha=0.8)
        self.fig.tight_layout()
        try:
            self.canvas.draw()
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    root = tk.Tk()
    TestApp(root)
    root.mainloop()
