#!/usr/bin/env python3
"""
export_model.py  —  Word AI  |  RP2040 Serial Dump → sklearn Model
===================================================================
Python 3.12 · scikit-learn · numpy

WHEN TO USE THIS SCRIPT
-----------------------
After the RP2040 has been running and learning via button taps, you can
extract its updated Q-table and neural weights over USB serial:

  STEP 1 — Hold the button on the RP2040 for ≥ 10 seconds.
            The OLED will show "Sending dump...". Wait for it to finish.
  STEP 2 — Run this script:
              python export_model.py
            or specify the port:
              python export_model.py --port /dev/ttyACM0
              python export_model.py --port COM3

  Or save the serial output to a file first and pass it with --file:
              python export_model.py --file dump.txt

KeyboardInterrupt (Ctrl-C) is handled gracefully.

OUTPUTS
-------
  model_updated.pkl            sklearn Pipeline (load in test_ui.py)
  q_table_dump.npy             Q-table as numpy array
  firmware/word_ai/model_data.h  regenerated C weight arrays
"""

import argparse
import json
import sys
import time
from pathlib import Path

import joblib
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    import serial
    import serial.tools.list_ports
    _HAS_SERIAL = True
except ImportError:
    _HAS_SERIAL = False
    print("[export] WARNING: pyserial not installed.")
    print("         pip install pyserial   OR   use --file <dump.txt>")

try:
    import tensorflow as tf
    _HAS_TF = True
    print(f"[export] tensorflow {tf.__version__} — TFLite export enabled.")
except ImportError:
    _HAS_TF = False


# ── Paths ──────────────────────────────────────────────────────────────────────
ROOT         = Path(__file__).resolve().parent
FIRMWARE_DIR = ROOT.parent / "firmware" / "word_ai"
OUT_PKL      = ROOT / "model_updated.pkl"
OUT_TFLITE   = ROOT / "model_updated.tflite"
OUT_QTABLE   = ROOT / "q_table_dump.npy"
MODEL_DATA_H = FIRMWARE_DIR / "model_data.h"

# ── Serial dump tags (must match reinforcement.cpp) ────────────────────────────
TAG_META    = "##META##"
TAG_Q_START = "##QTABLE_START##"
TAG_Q_END   = "##QTABLE_END##"
TAG_W_START = "##WEIGHTS_START##"
TAG_W_END   = "##WEIGHTS_END##"
TAG_LAYER   = "##LAYER##"

INPUT_DIM    = 26
HIDDEN_SIZES = (64, 32)


# ══════════════════════════════════════════════════════════════════════════════
#  Serial reader
# ══════════════════════════════════════════════════════════════════════════════

def list_ports() -> list[str]:
    if not _HAS_SERIAL:
        return []
    return [p.device for p in serial.tools.list_ports.comports()]


def read_serial_dump(port: str, baud: int = 115200, timeout_s: int = 30) -> str:
    """
    Wait for the RP2040 to send a complete CSV dump.
    Hold the device button for ≥10 s BEFORE running this.
    Press Ctrl-C to abort.
    """
    if not _HAS_SERIAL:
        raise RuntimeError("pyserial not installed. Use --file instead.")
    print(f"[export] Opening {port} @ {baud} baud …")
    print(f"[export] Waiting {timeout_s} s for dump. "
          f"(Hold RP2040 button ≥10 s if you haven't already.)")
    print("[export] Press Ctrl-C to abort.")

    ser      = serial.Serial(port, baud, timeout=1)
    lines:   list[str] = []
    in_dump  = False
    deadline = time.monotonic() + timeout_s

    try:
        while time.monotonic() < deadline:
            try:
                raw = ser.readline()
            except serial.SerialException as e:
                print(f"[export] Serial read error: {e}")
                break
            if not raw:
                continue
            line = raw.decode("utf-8", errors="ignore").strip()
            if not line:
                continue
            if any(t in line for t in (TAG_META, TAG_Q_START, TAG_W_START)):
                in_dump = True
            if in_dump:
                lines.append(line)
                print(f"  ← {line[:90]}")
            if TAG_W_END in line:
                print("[export] Dump complete.")
                break
    except KeyboardInterrupt:
        print("\n[export] Aborted by user (Ctrl-C).")
        if not lines:
            print("[export] No data received. Make sure you hold the button ≥10 s first.")
            ser.close()
            sys.exit(0)
    finally:
        ser.close()

    if not lines:
        raise RuntimeError(
            "No dump data received.\n"
            "Make sure you hold the RP2040 button for ≥10 seconds first,\n"
            "then run this script.")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  Dump parser
# ══════════════════════════════════════════════════════════════════════════════

def parse_dump(raw: str):
    meta         = {}
    q_rows:      list[list[float]] = []
    all_layers:  list[list[list[float]]] = []
    layer_rows:  list[list[float]] = []
    section      = None

    for line in raw.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith(TAG_META):
            try:
                meta = json.loads(line[len(TAG_META):].strip())
            except Exception as e:
                print(f"[export] META parse error: {e}")
            continue
        if TAG_Q_START in line:  section = "q"; continue
        if TAG_Q_END   in line:  section = None; continue
        if TAG_W_START in line:  section = "w"; layer_rows = []; continue
        if TAG_W_END   in line:
            if layer_rows: all_layers.append(layer_rows)
            section = None; continue
        if line.startswith(TAG_LAYER):
            if layer_rows: all_layers.append(layer_rows)
            layer_rows = []; continue
        try:
            vals = [float(v) for v in line.split(",") if v.strip()]
        except ValueError:
            continue
        if not vals:
            continue
        if section == "q":
            q_rows.append(vals)
        elif section == "w":
            layer_rows.append(vals)

    q_table = None
    if q_rows:
        mc     = max(len(r) for r in q_rows)
        padded = [r + [0.0]*(mc-len(r)) for r in q_rows]
        q_table = np.array(padded, dtype=np.float32)
        print(f"[export] Q-table shape: {q_table.shape}")

    weight_pairs = []
    for rows in all_layers:
        if not rows: continue
        arr = np.array(rows, dtype=np.float32)  # (fan_out, 1+fan_in)
        b   = arr[:, 0]                          # (fan_out,)
        W   = arr[:, 1:].T                       # (fan_in, fan_out)
        weight_pairs.append((W, b))
        print(f"[export] Layer: W{W.shape}  b{b.shape}")

    sc_meta      = meta.get("scaler", {})
    scaler_mean  = np.array(sc_meta.get("mean",  [0.0]*INPUT_DIM), dtype=np.float32)
    scaler_scale = np.array(sc_meta.get("scale", [1.0]*INPUT_DIM), dtype=np.float32)

    return meta, q_table, scaler_mean, scaler_scale, weight_pairs


# ══════════════════════════════════════════════════════════════════════════════
#  Model reconstruction
# ══════════════════════════════════════════════════════════════════════════════

def _c1(name, arr, cols=6):
    flat = arr.astype(np.float32).flatten().tolist()
    rows = ["  "+", ".join(f"{v:.8f}f" for v in flat[i:i+cols])
            for i in range(0, len(flat), cols)]
    return f"static const float {name}[{len(flat)}] = {{\n"+",\n".join(rows)+"\n};\n"

def _c2(name, arr, cols=6):
    A    = arr.astype(np.float32)
    flat = A.flatten().tolist()
    rows = ["  "+", ".join(f"{v:.8f}f" for v in flat[i:i+cols])
            for i in range(0, len(flat), cols)]
    return (f"static const float {name}[{A.shape[0]}][{A.shape[1]}] = {{\n"
            +",\n".join(rows)+"\n};\n")


def rebuild_pipeline(meta, weight_pairs, scaler_mean, scaler_scale):
    n_classes = meta.get("n_classes", 30)
    input_dim = meta.get("input_dim", INPUT_DIM)

    sc            = StandardScaler()
    sc.mean_      = scaler_mean.astype(np.float64)
    sc.scale_     = np.where(scaler_scale > 1e-8, scaler_scale, 1e-8).astype(np.float64)
    sc.var_       = sc.scale_ ** 2
    sc.n_samples_seen_ = 1
    sc.n_features_in_  = input_dim

    import warnings
    from sklearn.exceptions import ConvergenceWarning
    clf = MLPClassifier(hidden_layer_sizes=HIDDEN_SIZES, activation="relu",
                        solver="adam", max_iter=1, random_state=42)
    X_d = np.zeros((n_classes*2, input_dim), dtype=np.float32)
    y_d = np.repeat(np.arange(n_classes), 2)
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=ConvergenceWarning)
        clf.fit(X_d, y_d)

    expected = [(input_dim, HIDDEN_SIZES[0]),
                (HIDDEN_SIZES[0], HIDDEN_SIZES[1]),
                (HIDDEN_SIZES[1], n_classes)]
    for idx, ((W, b), exp) in enumerate(zip(weight_pairs, expected)):
        if W.shape == exp:
            clf.coefs_[idx]      = W.astype(np.float64)
            clf.intercepts_[idx] = b.astype(np.float64)
            print(f"[export] Layer {idx}: W{W.shape} injected ✓")
        else:
            print(f"[export] ⚠ Layer {idx} shape mismatch: "
                  f"got {W.shape}, expected {exp}")

    return Pipeline([("sc", sc), ("clf", clf)])


def write_header(pipeline, meta):
    sc  = pipeline.named_steps["sc"]
    clf = pipeline.named_steps["clf"]
    n   = meta.get("n_classes", 30)
    cids   = meta.get("cid_list", list(range(1, n+1)))
    clsmap = meta.get("classes",  {str(c): f"word_{c}" for c in cids})
    ids_s   = ", ".join(str(c) for c in cids)
    names_s = ", ".join(f'"{clsmap.get(str(c),str(c))}"' for c in cids)
    W0,b0 = clf.coefs_[0].astype(np.float32), clf.intercepts_[0].astype(np.float32)
    W1,b1 = clf.coefs_[1].astype(np.float32), clf.intercepts_[1].astype(np.float32)
    W2,b2 = clf.coefs_[2].astype(np.float32), clf.intercepts_[2].astype(np.float32)
    body = (
        "// Rebuilt by pc/export_model.py from RP2040 serial dump\n"
        "#pragma once\n#ifndef MODEL_DATA_H\n#define MODEL_DATA_H\n#include <stdint.h>\n\n"
        "alignas(8) static const uint8_t MODEL_DATA[] = {0x00};\n"
        "static const uint32_t MODEL_DATA_LEN = 1U;\n\n"
        f"static const int N_CLASSES = {n};\nstatic const int INPUT_DIM = {meta.get('input_dim',26)};\n\n"
        f"static const int         CLASS_IDS[{n}]   = {{ {ids_s} }};\n"
        f"static const char* const CLASS_NAMES[{n}] = {{ {names_s} }};\n\n"
        +_c1("SCALER_MEAN", sc.mean_.astype(np.float32))
        +_c1("SCALER_SCALE",sc.scale_.astype(np.float32))
        +_c2("NN_W0",W0)+_c1("NN_b0",b0)
        +_c2("NN_W1",W1)+_c1("NN_b1",b1)
        +_c2("NN_W2",W2)+_c1("NN_b2",b2)
        +"\n#endif // MODEL_DATA_H\n"
    )
    FIRMWARE_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DATA_H.write_text(body, encoding="utf-8")
    print(f"[export] model_data.h → {MODEL_DATA_H}")


def tflite_export(pipeline, meta):
    if not _HAS_TF:
        print("[export] tensorflow not available — skipping TFLite.")
        return
    clf  = pipeline.named_steps["clf"]
    n    = meta.get("n_classes", 30)
    idim = meta.get("input_dim", INPUT_DIM)
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(idim,)),
        tf.keras.layers.Dense(64, activation="relu"),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dense(n,  activation="softmax"),
    ])
    model(np.zeros((1, idim), dtype=np.float32))
    dl = [l for l in model.layers if hasattr(l, "kernel")]
    for i,(dl_,W,b) in enumerate(zip(dl,clf.coefs_,clf.intercepts_)):
        if W.shape == dl_.kernel.shape:
            dl_.set_weights([W.astype(np.float32), b.astype(np.float32)])
    conv   = tf.lite.TFLiteConverter.from_keras_model(model)
    conv.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite = conv.convert()
    OUT_TFLITE.write_bytes(tflite)
    print(f"[export] TFLite → {OUT_TFLITE}  ({len(tflite)} bytes)")


# ══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(
        description="Read RP2040 serial dump and rebuild sklearn model.",
        epilog=(
            "IMPORTANT: Hold the RP2040 button for ≥10 seconds FIRST,\n"
            "then run this script.  Or save the serial output to a file\n"
            "and pass it with  --file dump.txt"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--port",    default=None)
    parser.add_argument("--baud",    default=115200, type=int)
    parser.add_argument("--timeout", default=30,     type=int)
    parser.add_argument("--file",    default=None,   metavar="DUMP_FILE")
    args = parser.parse_args()

    if args.file:
        p = Path(args.file)
        if not p.exists():
            print(f"[export] File not found: {args.file}")
            sys.exit(1)
        raw = p.read_text(encoding="utf-8")
        print(f"[export] Reading from {p}  ({len(raw)} chars)")
    else:
        if not _HAS_SERIAL:
            print("[export] pyserial required for serial reading.")
            print("         pip install pyserial")
            sys.exit(1)
        port = args.port
        if port is None:
            ports = list_ports()
            if not ports:
                print("[export] No serial ports found. Connect the RP2040.")
                sys.exit(1)
            port = ports[0]
            print(f"[export] Auto-selected port: {port}")
        try:
            raw = read_serial_dump(port, args.baud, args.timeout)
        except KeyboardInterrupt:
            print("\n[export] Cancelled.")
            sys.exit(0)
        except RuntimeError as e:
            print(f"[export] {e}")
            sys.exit(1)

    if not raw.strip():
        print("[export] Empty dump.")
        sys.exit(1)

    meta, q_table, scaler_mean, scaler_scale, weight_pairs = parse_dump(raw)

    if q_table is not None:
        np.save(str(OUT_QTABLE), q_table)
        print(f"[export] Q-table → {OUT_QTABLE}")

    if not weight_pairs:
        print("[export] No weight rows found — cannot rebuild model.")
        sys.exit(1)

    pipeline = rebuild_pipeline(meta, weight_pairs, scaler_mean, scaler_scale)
    joblib.dump(pipeline, OUT_PKL)
    print(f"[export] Pipeline → {OUT_PKL}")
    write_header(pipeline, meta)
    tflite_export(pipeline, meta)
    print("[export] Done.")


if __name__ == "__main__":
    main()
