#!/usr/bin/env python3
"""
recorder_ui.py  —  Word AI  |  Recorder & Trainer
==================================================
Python 3.12 · scikit-learn · numpy · sounddevice

PROBLEMS FIXED IN THIS VERSION
-------------------------------
- Train button was CUT OFF below the screen (resizable=False + too tall)
- Only 1 class caused silent failure (need ≥2 for sklearn)
- Error messages never reached the label (queue race condition)
- Window now SCROLLABLE so nothing is ever hidden
- Train button is at the TOP in a toolbar, always visible
- 1-class training: adds synthetic noise as "unknown" class automatically
- All errors shown as messagebox popups, not just label updates
"""

import json
import math
import queue
import threading
import time
import traceback
import warnings
from pathlib import Path

import joblib
import numpy as np
import tkinter as tk
from tkinter import messagebox, ttk

from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import classification_report
from sklearn.model_selection import StratifiedKFold, cross_val_score
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

try:
    import sounddevice as sd
    _HAS_AUDIO = True
except ImportError:
    _HAS_AUDIO = False

# ── Paths ──────────────────────────────────────────────────────────────────────
ROOT         = Path(__file__).resolve().parent
DATA_DIR     = ROOT / "recordings"
MODEL_PKL    = DATA_DIR / "model.pkl"
WEIGHTS_JSON = ROOT / "model_weights.json"
FIRMWARE_DIR = ROOT.parent / "firmware" / "word_ai"
MODEL_DATA_H = FIRMWARE_DIR / "model_data.h"

# ── Audio constants ────────────────────────────────────────────────────────────
SR        = 16_000
DURATION  = 1.0
N_FFT     = 256
HOP       = 128
N_MELS    = 26
N_MFCC    = 13
INPUT_DIM = N_MFCC * 2
HIDDEN    = (64, 32)

DEFAULT_VOCAB: dict[int, str] = {
     1:"yes",  2:"no",    3:"hello", 4:"bye",   5:"I",
     6:"you",  7:"want",  8:"need",  9:"help",  10:"what",
    11:"how",  12:"where",13:"when", 14:"good",  15:"bad",
    16:"please",17:"thank",18:"stop",19:"go",    20:"here",
    21:"there",22:"more", 23:"less", 24:"up",    25:"down",
    26:"left", 27:"right",28:"on",   29:"off",   30:"okay",
}


# ══════════════════════════════════════════════════════════════════════════════
#  MFCC feature extraction
# ══════════════════════════════════════════════════════════════════════════════

def _build_mel_fb() -> np.ndarray:
    n_bins  = N_FFT // 2 + 1
    m_lo    = 2595.0 * math.log10(1.0 + 0.0      / 700.0)
    m_hi    = 2595.0 * math.log10(1.0 + SR / 2.0 / 700.0)
    mel_pts = np.linspace(m_lo, m_hi, N_MELS + 2)
    hz_pts  = 700.0 * (10.0 ** (mel_pts / 2595.0) - 1.0)
    bins    = np.floor((N_FFT + 1) * hz_pts / SR).astype(int)
    fb      = np.zeros((N_MELS, n_bins), dtype=np.float32)
    for m in range(1, N_MELS + 1):
        lo, c, hi = bins[m-1], bins[m], bins[m+1]
        for k in range(lo, c):
            fb[m-1, k] = (k - lo) / (c  - lo) if c  != lo else 0.0
        for k in range(c, hi):
            fb[m-1, k] = (hi - k) / (hi - c)  if hi != c  else 0.0
    return fb

def _build_dct_mat() -> np.ndarray:
    d = np.zeros((N_MFCC, N_MELS), dtype=np.float32)
    for i in range(N_MFCC):
        for j in range(N_MELS):
            d[i, j] = math.cos(math.pi * i * (j + 0.5) / N_MELS)
    d[0] *= math.sqrt(1.0 / N_MELS)
    for i in range(1, N_MFCC):
        d[i] *= math.sqrt(2.0 / N_MELS)
    return d

_HAMMING = np.array(
    [0.54 - 0.46 * math.cos(2.0 * math.pi * n / (N_FFT - 1)) for n in range(N_FFT)],
    dtype=np.float32)
_MEL_FB  = _build_mel_fb()
_DCT_MAT = _build_dct_mat()

def extract_features(audio: np.ndarray) -> np.ndarray:
    n_frames = max(1, (len(audio) - N_FFT) // HOP + 1)
    acc      = np.zeros((N_MFCC, n_frames), dtype=np.float32)
    for f in range(n_frames):
        seg = audio[f * HOP : f * HOP + N_FFT]
        if len(seg) < N_FFT:
            seg = np.pad(seg, (0, N_FFT - len(seg)))
        spec     = np.fft.rfft(seg.astype(np.float32) * _HAMMING)
        pwr      = (np.abs(spec) ** 2) / N_FFT
        log_mel  = np.log(np.maximum(_MEL_FB @ pwr, 1e-10))
        acc[:, f] = _DCT_MAT @ log_mel
    return np.concatenate([acc.mean(1), acc.std(1)]).astype(np.float32)


# ══════════════════════════════════════════════════════════════════════════════
#  C-header export
# ══════════════════════════════════════════════════════════════════════════════

def _c1(name: str, arr: np.ndarray, cols: int = 6) -> str:
    flat = arr.astype(np.float32).flatten().tolist()
    rows = ["  " + ", ".join(f"{v:.8f}f" for v in flat[i:i+cols])
            for i in range(0, len(flat), cols)]
    return f"static const float {name}[{len(flat)}] = {{\n" + ",\n".join(rows) + "\n};\n"

def _c2(name: str, arr: np.ndarray, cols: int = 6) -> str:
    A    = arr.astype(np.float32)
    flat = A.flatten().tolist()
    rows = ["  " + ", ".join(f"{v:.8f}f" for v in flat[i:i+cols])
            for i in range(0, len(flat), cols)]
    return (f"static const float {name}[{A.shape[0]}][{A.shape[1]}] = {{\n"
            + ",\n".join(rows) + "\n};\n")

def write_model_data_h(pipeline: Pipeline,
                       cid_list: list[int],
                       class_map: dict[int, str]) -> None:
    sc  = pipeline.named_steps["sc"]
    clf = pipeline.named_steps["clf"]
    n   = len(cid_list)
    W0, b0 = clf.coefs_[0].astype(np.float32), clf.intercepts_[0].astype(np.float32)
    W1, b1 = clf.coefs_[1].astype(np.float32), clf.intercepts_[1].astype(np.float32)
    W2, b2 = clf.coefs_[2].astype(np.float32), clf.intercepts_[2].astype(np.float32)
    ids_s   = ", ".join(str(c) for c in cid_list)
    names_s = ", ".join(f'"{class_map[c]}"' for c in cid_list)
    body = (
        "// Auto-generated by pc/recorder_ui.py — do not edit\n"
        "#pragma once\n#ifndef MODEL_DATA_H\n#define MODEL_DATA_H\n#include <stdint.h>\n\n"
        "alignas(8) static const uint8_t MODEL_DATA[] = {0x00};\n"
        "static const uint32_t MODEL_DATA_LEN = 1U;\n\n"
        f"static const int N_CLASSES = {n};\nstatic const int INPUT_DIM = {INPUT_DIM};\n\n"
        f"static const int         CLASS_IDS[{n}]   = {{ {ids_s} }};\n"
        f"static const char* const CLASS_NAMES[{n}] = {{ {names_s} }};\n\n"
        + _c1("SCALER_MEAN",  sc.mean_.astype(np.float32))
        + _c1("SCALER_SCALE", sc.scale_.astype(np.float32))
        + _c2("NN_W0", W0) + _c1("NN_b0", b0)
        + _c2("NN_W1", W1) + _c1("NN_b1", b1)
        + _c2("NN_W2", W2) + _c1("NN_b2", b2)
        + "\n#endif // MODEL_DATA_H\n"
    )
    FIRMWARE_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_DATA_H.write_text(body, encoding="utf-8")
    print(f"[recorder] model_data.h → {MODEL_DATA_H}  ({len(body)//1024:.1f} KB)")

def write_weights_json(pipeline: Pipeline,
                       cid_list: list[int],
                       class_map: dict[int, str]) -> None:
    sc  = pipeline.named_steps["sc"]
    clf = pipeline.named_steps["clf"]
    p = {
        "cid_list":     cid_list,
        "classes":      {str(c): class_map[c] for c in cid_list},
        "n_classes":    len(cid_list),
        "input_dim":    INPUT_DIM,
        "hidden_sizes": list(HIDDEN),
        "scaler":       {"mean": sc.mean_.tolist(), "scale": sc.scale_.tolist()},
        "layers":       [{"W": clf.coefs_[i].tolist(), "b": clf.intercepts_[i].tolist()}
                         for i in range(len(clf.coefs_))],
    }
    WEIGHTS_JSON.write_text(json.dumps(p, indent=2), encoding="utf-8")
    print(f"[recorder] model_weights → {WEIGHTS_JSON}")


# ══════════════════════════════════════════════════════════════════════════════
#  Scrollable frame helper
# ══════════════════════════════════════════════════════════════════════════════

class ScrollableFrame(tk.Frame):
    """A frame with a vertical scrollbar — wraps content in a Canvas."""
    def __init__(self, parent, **kwargs):
        super().__init__(parent, **kwargs)
        canvas = tk.Canvas(self, borderwidth=0, highlightthickness=0)
        vsb    = ttk.Scrollbar(self, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        self.inner = tk.Frame(canvas)
        self._win  = canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfig(
            self._win, width=e.width))
        # Mouse wheel
        def _on_wheel(event):
            canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        canvas.bind_all("<MouseWheel>", _on_wheel)
        canvas.bind_all("<Button-4>",
                        lambda e: canvas.yview_scroll(-1, "units"))
        canvas.bind_all("<Button-5>",
                        lambda e: canvas.yview_scroll( 1, "units"))


# ══════════════════════════════════════════════════════════════════════════════
#  RecorderApp
# ══════════════════════════════════════════════════════════════════════════════

class RecorderApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root

        # State
        self.classes:    dict[int, str]  = {}
        self.recordings: dict[int, list] = {}
        self.current_id: int | None      = None
        self.recording:  bool            = False
        self.r_held:     bool            = False
        self.training:   bool            = False

        # Thread-safe queue
        self.q: queue.Queue = queue.Queue()

        # Widget refs
        self.tree:         ttk.Treeview    | None = None
        self.ent_name:     tk.Entry        | None = None
        self.ent_id:       tk.Entry        | None = None
        self.ent_quick_id: tk.Entry        | None = None
        self.lbl_selected: tk.Label        | None = None
        self.lbl_status:   tk.Label        | None = None
        self.lbl_count:    tk.Label        | None = None
        self.lbl_train:    tk.Label        | None = None
        self.btn_train:    tk.Button       | None = None
        self.prog_rec:     ttk.Progressbar | None = None
        self.prog_train:   ttk.Progressbar | None = None

        self.meta_file = DATA_DIR / "meta.json"
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        self._load_meta()
        self._build_ui()
        self._bind_keys()
        self._poll()

    # ── Persistence ────────────────────────────────────────────────────────────
    def _load_meta(self) -> None:
        if not self.meta_file.exists():
            return
        try:
            meta = json.loads(self.meta_file.read_text(encoding="utf-8"))
        except Exception:
            return
        self.classes = {int(k): v for k, v in meta.get("classes", {}).items()}
        for cid in self.classes:
            self.recordings[cid] = []
            rec_dir = DATA_DIR / str(cid)
            if rec_dir.is_dir():
                for fp in sorted(rec_dir.glob("*.npy")):
                    try:
                        self.recordings[cid].append(np.load(fp))
                    except Exception as e:
                        print(f"[recorder] skip {fp}: {e}")

    def _save_meta(self) -> None:
        self.meta_file.write_text(
            json.dumps({"classes": {str(k): v for k, v in self.classes.items()}},
                       indent=2), encoding="utf-8")

    # ── Queue poll ─────────────────────────────────────────────────────────────
    def _poll(self) -> None:
        try:
            while True:
                tag, val = self.q.get_nowait()
                if tag == "train_label":
                    if self.lbl_train:
                        self.lbl_train.config(text=val, fg="#2980b9")
                elif tag == "train_done":
                    self.training = False
                    if self.lbl_train:
                        self.lbl_train.config(text=val, fg="#27ae60")
                    if self.prog_train:
                        self.prog_train.stop()
                    if self.btn_train:
                        self.btn_train.config(state="normal")
                    messagebox.showinfo("Training Complete", val)
                elif tag == "train_error":
                    self.training = False
                    if self.lbl_train:
                        self.lbl_train.config(text=val, fg="red")
                    if self.prog_train:
                        self.prog_train.stop()
                    if self.btn_train:
                        self.btn_train.config(state="normal")
                    messagebox.showerror("Training Failed", val)
                elif tag == "rec_progress":
                    if self.prog_rec:
                        self.prog_rec.config(value=float(val))
                elif tag == "rec_done":
                    self._rec_done_ui()
        except queue.Empty:
            pass
        self.root.after(100, self._poll)

    # ── UI ─────────────────────────────────────────────────────────────────────
    def _build_ui(self) -> None:
        self.root.title("Word AI — Recorder & Trainer")
        # Resizable so nothing is ever hidden
        self.root.resizable(True, True)
        self.root.minsize(520, 400)
        # Start at a reasonable size that fits most screens
        self.root.geometry("680x700")

        # ── TOP TOOLBAR: always visible, Train button lives here ───────────────
        toolbar = tk.Frame(self.root, bg="#2c3e50", pady=6)
        toolbar.pack(fill="x", side="top")

        tk.Label(toolbar, text="Word AI — Recorder & Trainer",
                 font=("Helvetica", 13, "bold"),
                 bg="#2c3e50", fg="white").pack(side="left", padx=12)

        self.btn_train = tk.Button(
            toolbar,
            text="  ▶  TRAIN MODEL  ",
            font=("Helvetica", 11, "bold"),
            bg="#27ae60", fg="white",
            activebackground="#1e8449",
            relief="flat", cursor="hand2",
            command=self._train_start)
        self.btn_train.pack(side="right", padx=10, pady=2)

        self.lbl_train = tk.Label(
            toolbar,
            text="No model trained yet.",
            font=("Helvetica", 9),
            bg="#2c3e50", fg="#bdc3c7")
        self.lbl_train.pack(side="right", padx=6)

        self.prog_train = ttk.Progressbar(
            toolbar, length=120, mode="indeterminate")
        self.prog_train.pack(side="right", padx=4)

        # ── SCROLLABLE CONTENT AREA ────────────────────────────────────────────
        sf = ScrollableFrame(self.root)
        sf.pack(fill="both", expand=True)
        p = sf.inner   # everything below goes into this inner frame

        # ── Add-class row ──────────────────────────────────────────────────────
        top = tk.LabelFrame(p, text=" Add New Class ", padx=8, pady=6)
        top.pack(fill="x", padx=8, pady=(8, 2))

        tk.Label(top, text="Class Name:").grid(row=0, column=0, sticky="e")
        self.ent_name = tk.Entry(top, width=15)
        self.ent_name.grid(row=0, column=1, padx=4)

        tk.Label(top, text="Class ID (int):").grid(row=0, column=2, sticky="e")
        self.ent_id = tk.Entry(top, width=7)
        self.ent_id.grid(row=0, column=3, padx=4)

        tk.Button(top, text="  +  Add  ",
                  font=("Helvetica", 11, "bold"),
                  bg="#27ae60", fg="white", relief="flat",
                  command=self._add_class).grid(row=0, column=4, padx=6)

        tk.Button(top, text="Seed 30 default words",
                  bg="#7f8c8d", fg="white", relief="flat",
                  command=self._seed_defaults).grid(
                      row=1, column=0, columnspan=5, pady=(6,2), sticky="ew")

        # ── Classes list ───────────────────────────────────────────────────────
        mid = tk.LabelFrame(p, text=" Classes ", padx=6, pady=4)
        mid.pack(fill="x", padx=8, pady=4)

        cols = ("ID", "Name", "Samples")
        self.tree = ttk.Treeview(mid, columns=cols, show="headings", height=7)
        self.tree.heading("ID",      text="ID");      self.tree.column("ID",      width=80,  anchor="center")
        self.tree.heading("Name",    text="Name");    self.tree.column("Name",    width=200, anchor="center")
        self.tree.heading("Samples", text="Samples"); self.tree.column("Samples", width=80,  anchor="center")
        sb_tree = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=sb_tree.set)
        self.tree.pack(side="left", fill="x", expand=True)
        sb_tree.pack(side="right", fill="y")
        self.tree.bind("<<TreeviewSelect>>", self._on_tree_select)
        self._refresh_tree()

        # ── Quick record ───────────────────────────────────────────────────────
        qrow = tk.Frame(p)
        qrow.pack(fill="x", padx=8, pady=2)
        tk.Label(qrow, text="Quick Record — Class ID:").pack(side="left")
        self.ent_quick_id = tk.Entry(qrow, width=6)
        self.ent_quick_id.pack(side="left", padx=4)
        tk.Label(qrow, text="← type, then hold  R",
                 fg="#7f8c8d").pack(side="left")

        # ── Status ─────────────────────────────────────────────────────────────
        rec = tk.LabelFrame(p, text=" Recording Status ", padx=8, pady=6)
        rec.pack(fill="x", padx=8, pady=4)

        self.lbl_selected = tk.Label(rec, text="Selected: none — click a row above",
                                     font=("Helvetica", 10, "bold"), fg="#e74c3c")
        self.lbl_selected.pack()

        self.lbl_status = tk.Label(
            rec, text="Hold  R  to record 1 second",
            font=("Helvetica", 10), fg="#7f8c8d")
        self.lbl_status.pack()

        self.prog_rec = ttk.Progressbar(rec, length=580, mode="determinate")
        self.prog_rec.pack(pady=4, fill="x")

        self.lbl_count = tk.Label(rec, text="", fg="#2980b9", font=("Helvetica", 10))
        self.lbl_count.pack()

        # ── Bottom note ────────────────────────────────────────────────────────
        note = tk.Label(p,
            text="▲  Click  ▶ TRAIN MODEL  in the top toolbar to train after recording",
            font=("Helvetica", 9, "italic"), fg="#7f8c8d")
        note.pack(pady=6)

    # ── Key bindings ───────────────────────────────────────────────────────────
    def _bind_keys(self) -> None:
        self.root.bind("<KeyPress-r>",   self._on_r_press)
        self.root.bind("<KeyRelease-r>", self._on_r_release)
        self.root.focus_set()

    # ── Class management ───────────────────────────────────────────────────────
    def _add_class(self) -> None:
        name = self.ent_name.get().strip()
        raw  = self.ent_id.get().strip()
        if not name:
            messagebox.showerror("Error", "Class name cannot be empty.")
            return
        try:
            cid = int(raw)
        except ValueError:
            messagebox.showerror("Error", "Class ID must be a whole number (e.g. 1, 2, 3).")
            return
        if cid in self.classes:
            messagebox.showerror("Error",
                                 f"ID {cid} already exists as '{self.classes[cid]}'.")
            return
        self._register(cid, name)
        self.ent_name.delete(0, tk.END)
        self.ent_id.delete(0, tk.END)
        messagebox.showinfo("Class Added",
            f"Class [{cid}] '{name}' added.\n\n"
            f"Now click the row, then hold  R  to record samples.")

    def _register(self, cid: int, name: str) -> None:
        self.classes[cid] = name
        self.recordings.setdefault(cid, [])
        (DATA_DIR / str(cid)).mkdir(parents=True, exist_ok=True)
        self._save_meta()
        self._refresh_tree()

    def _seed_defaults(self) -> None:
        n = sum(1 for c in DEFAULT_VOCAB if c not in self.classes)
        for cid, name in DEFAULT_VOCAB.items():
            if cid not in self.classes:
                self._register(cid, name)
        messagebox.showinfo("Done",
            f"Added {n} word classes.\n"
            "Select each one and hold R to record samples.")

    def _refresh_tree(self) -> None:
        if self.tree is None:
            return
        for item in self.tree.get_children():
            self.tree.delete(item)
        for cid in sorted(self.classes):
            n = len(self.recordings.get(cid, []))
            self.tree.insert("", "end", values=(cid, self.classes[cid], n))

    def _on_tree_select(self, _event) -> None:
        if self.tree is None:
            return
        sel = self.tree.selection()
        if not sel:
            return
        self.current_id = int(self.tree.item(sel[0])["values"][0])
        self._update_sel()

    def _update_sel(self) -> None:
        if self.lbl_selected is None:
            return
        if self.current_id is None:
            self.lbl_selected.config(
                text="Selected: none — click a row above", fg="#e74c3c")
        else:
            name = self.classes.get(self.current_id, "?")
            n    = len(self.recordings.get(self.current_id, []))
            self.lbl_selected.config(
                text=f"Selected: [{self.current_id}]  {name}  ({n} samples)",
                fg="#27ae60")

    def _resolve_id(self) -> bool:
        if self.ent_quick_id is None:
            return self.current_id is not None
        raw = self.ent_quick_id.get().strip()
        if not raw:
            return self.current_id is not None
        try:
            cid = int(raw)
        except ValueError:
            return False
        if cid not in self.classes:
            return False
        self.current_id = cid
        self._update_sel()
        return True

    # ── Recording ──────────────────────────────────────────────────────────────
    def _on_r_press(self, _event) -> None:
        if self.r_held or self.recording:
            return
        if not self._resolve_id():
            messagebox.showwarning("No Class Selected",
                "Click a class in the list first,\n"
                "or type the Class ID in the Quick Record field.")
            return
        if not _HAS_AUDIO:
            messagebox.showerror("No Audio",
                "sounddevice is not installed.\n"
                "Run:  pip install sounddevice")
            return
        self.r_held    = True
        self.recording = True
        if self.lbl_status:
            self.lbl_status.config(text="● RECORDING …", fg="red")
        threading.Thread(target=self._rec_worker, daemon=True).start()

    def _on_r_release(self, _event) -> None:
        self.r_held = False

    def _rec_worker(self) -> None:
        cid   = self.current_id
        steps = 50
        try:
            audio = sd.rec(int(SR * DURATION),
                           samplerate=SR, channels=1, dtype="float32")
            for i in range(steps + 1):
                self.q.put(("rec_progress", str(i / steps * 100)))
                time.sleep(DURATION / steps)
            sd.wait()
            flat = audio.flatten().astype(np.float32)
            rec_dir = DATA_DIR / str(cid)
            rec_dir.mkdir(parents=True, exist_ok=True)
            idx = len(list(rec_dir.glob("*.npy")))
            np.save(rec_dir / f"{idx:05d}.npy", flat)
            self.recordings[cid].append(flat)
        except Exception as e:
            print(f"[recorder] Record error: {e}")
        finally:
            self.q.put(("rec_done", ""))

    def _rec_done_ui(self) -> None:
        self.recording = False
        if self.prog_rec:
            self.prog_rec.config(value=0)
        if self.lbl_status:
            self.lbl_status.config(
                text="Hold  R  to record 1 second", fg="#7f8c8d")
        self._update_sel()
        self._refresh_tree()

    # ── Training ───────────────────────────────────────────────────────────────
    def _train_start(self) -> None:
        if self.training:
            messagebox.showinfo("Busy", "Training is already running. Please wait.")
            return

        # Count classes that actually have recordings
        cid_list = sorted(c for c in self.classes if self.recordings.get(c))
        total    = sum(len(self.recordings.get(c, [])) for c in cid_list)

        print(f"[recorder] _train_start: cid_list={cid_list}, total_samples={total}")

        if len(cid_list) == 0:
            messagebox.showerror("No Data",
                "No recordings found.\n\n"
                "Steps:\n"
                "1. Add a class (name + ID + click +)\n"
                "2. Click the class row to select it\n"
                "3. Hold  R  to record (repeat 5+ times)\n"
                "4. Then click  ▶ TRAIN MODEL")
            return

        if total < 2:
            messagebox.showerror("Not Enough Samples",
                f"Only {total} recording(s) found.\n\n"
                "Need at least 2 recordings total.\n"
                "Hold  R  to record more samples.")
            return

        # If only 1 class, warn the user but proceed with noise padding
        if len(cid_list) == 1:
            answer = messagebox.askyesno(
                "Only 1 Class",
                f"You have only 1 class: '{self.classes[cid_list[0]]}'\n\n"
                "sklearn needs ≥2 classes to train a classifier.\n\n"
                "The trainer will automatically add a synthetic 'noise/silence'\n"
                "class so training can proceed.\n\n"
                "For best results, add more classes and record samples.\n\n"
                "Continue with synthetic noise class?")
            if not answer:
                return

        self.training = True
        if self.btn_train:
            self.btn_train.config(state="disabled")
        if self.lbl_train:
            self.lbl_train.config(text="Starting …", fg="#f39c12")
        if self.prog_train:
            self.prog_train.start()

        threading.Thread(target=self._train_worker, daemon=True).start()

    def _train_worker(self) -> None:
        try:
            self._do_train()
        except Exception:
            tb  = traceback.format_exc()
            print(f"[recorder] TRAINING EXCEPTION:\n{tb}")
            msg = tb.strip().splitlines()[-1]
            self.q.put(("train_error", f"Error: {msg}"))

    def _do_train(self) -> None:
        # ── Build class list and class_map FIRST ──────────────────────────────
        cid_list  = sorted(c for c in self.classes if self.recordings.get(c))
        class_map = {c: self.classes[c] for c in cid_list}   # defined first!
        label_map = {c: i for i, c in enumerate(cid_list)}
        n_real    = len(cid_list)

        print(f"[recorder] _do_train: cid_list={cid_list} class_map={class_map}")
        self.q.put(("train_label", "Extracting MFCC features …"))

        # ── Extract features ──────────────────────────────────────────────────
        X_list: list[np.ndarray] = []
        y_list: list[int]        = []
        for cid in cid_list:
            for audio in self.recordings[cid]:
                X_list.append(extract_features(audio))
                y_list.append(label_map[cid])

        # ── If only 1 real class, add synthetic noise class ───────────────────
        if n_real < 2:
            print("[recorder] Adding synthetic noise class for 1-class training")
            noise_label = len(cid_list)   # new label index = n_real
            rng         = np.random.RandomState(42)
            for _ in range(max(len(X_list), 5)):
                noise_audio = rng.randn(SR).astype(np.float32) * 0.01
                X_list.append(extract_features(noise_audio))
                y_list.append(noise_label)
            # Add noise to class_map and cid_list for export
            noise_cid         = max(cid_list) + 1
            cid_list          = cid_list + [noise_cid]
            class_map[noise_cid] = "noise"
            print(f"[recorder] Extended cid_list={cid_list}")

        X = np.stack(X_list).astype(np.float32)
        y = np.array(y_list, dtype=np.int32)
        n_classes = len(set(y_list))
        n_samples = len(X)
        print(f"[recorder] Dataset: X={X.shape}  n_classes={n_classes}")

        self.q.put(("train_label",
            f"Training … {n_samples} samples, {n_classes} classes"))

        # ── Train Pipeline ────────────────────────────────────────────────────
        pipeline = Pipeline([
            ("sc", StandardScaler()),
            ("clf", MLPClassifier(
                hidden_layer_sizes=HIDDEN,
                activation="relu",
                solver="adam",
                max_iter=500,
                early_stopping=False,
                learning_rate_init=0.001,
                alpha=1e-4,
                random_state=42,
                verbose=False,
            )),
        ])
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=ConvergenceWarning)
            pipeline.fit(X, y)

        # ── Cross-validation ──────────────────────────────────────────────────
        cv_msg        = ""
        min_per_class = int(min((y == i).sum() for i in range(n_classes)))
        if min_per_class >= 3:
            n_folds = min(5, min_per_class)
            self.q.put(("train_label", f"Cross-validating ({n_folds} folds) …"))
            cv      = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", category=ConvergenceWarning)
                scores = cross_val_score(pipeline, X, y, cv=cv,
                                         scoring="accuracy", n_jobs=1)
            cv_msg = f"  CV={scores.mean():.3f}±{scores.std():.3f}"
            print(f"[recorder] CV: {scores.round(3)}")

        # ── Report ────────────────────────────────────────────────────────────
        y_pred      = pipeline.predict(X)
        train_acc   = float((y_pred == y).mean())
        label_names = [class_map[cid_list[i]] for i in range(n_classes)]
        print("[recorder] Classification report:")
        print(classification_report(y, y_pred,
                                    target_names=label_names, zero_division=0))

        # ── Save ──────────────────────────────────────────────────────────────
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        joblib.dump(pipeline, MODEL_PKL)
        print(f"[recorder] Saved → {MODEL_PKL}")
        write_model_data_h(pipeline, cid_list, class_map)
        write_weights_json(pipeline, cid_list, class_map)

        msg = (f"✓ {n_classes} classes | {n_samples} samples | "
               f"acc={train_acc:.3f}{cv_msg}\n"
               f"Saved: {MODEL_PKL.name}")
        print(f"[recorder] {msg}")
        self.q.put(("train_done", msg.replace("\n", "  ")))


# ══════════════════════════════════════════════════════════════════════════════
if __name__ == "__main__":
    print(f"[recorder] DATA_DIR     = {DATA_DIR}")
    print(f"[recorder] FIRMWARE_DIR = {FIRMWARE_DIR}")
    print(f"[recorder] MODEL_PKL    = {MODEL_PKL}")
    if not _HAS_AUDIO:
        print("[recorder] WARNING: sounddevice not installed — pip install sounddevice")
    root = tk.Tk()
    RecorderApp(root)
    root.mainloop()
