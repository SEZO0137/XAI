# Word AI System  —  v2  (scikit-learn · Python 3.12)
**Seeed XIAO RP2040 · INMP441 · SSD1306 OLED**

> Listening AI (sklearn MLP) + Reinforcement Learning (Q-table + neural matrix)

---

## Directory layout

```
word_ai_system/
├── README.md
├── requirements.txt
│
├── pc/                            ← run these on your PC
│   ├── recorder_ui.py             collect samples, train, export weights
│   ├── test_ui.py                 live mic test + pie chart
│   └── export_model.py            serial CSV dump → sklearn pkl + model_data.h
│
└── firmware/
    └── word_ai/                   ← open this folder in Arduino IDE
        ├── word_ai.ino            main sketch (flash this)
        ├── OLED.h / OLED.cpp      SSD1306 library (provided, unmodified)
        ├── audio_constants.h      Hamming / Mel / DCT constants (pre-computed)
        ├── audio_features.h/.cpp  INMP441 I²S driver + streaming MFCC
        ├── inference.h/.cpp       sklearn-equivalent MLP inference (C float)
        ├── reinforcement.h/.cpp   Q-table + neural matrix RL agent
        └── model_data.h           auto-generated weight arrays (train first!)
```

---

## System diagram

```
┌──────────────────────────────────────────────────────┐
│ PC  (Python 3.12)                                    │
│                                                      │
│  recorder_ui.py                                      │
│  ┌────────────────────────────────────────────┐      │
│  │ Tkinter UI                                 │      │
│  │  +  Add class (name + ID)                  │      │
│  │  R  Hold to record 1 s → extract MFCC      │      │
│  │     → save recordings/<id>/<n>.npy         │      │
│  │                                            │      │
│  │ Train:  StandardScaler → MLPClassifier     │      │
│  │         hidden=(64,32)  relu  adam         │      │
│  │  ↓ joblib                                  │      │
│  │  recordings/model.pkl                      │      │
│  │  ↓ C float arrays                          │      │
│  │  firmware/word_ai/model_data.h             │      │
│  └────────────────────────────────────────────┘      │
│                                                      │
│  test_ui.py          export_model.py                 │
│  ┌──────────────┐    ┌────────────────────────┐      │
│  │ Load .pkl    │    │ Read RP2040 serial dump │      │
│  │ Hold R → mic │    │ Parse Q-table + weights│      │
│  │ predict_proba│    │ Rebuild sklearn pkl     │      │
│  │ pie chart    │    │ Regenerate model_data.h │      │
│  └──────────────┘    │ Optional: → TFLite      │      │
│                      └────────────────────────┘      │
└──────────────┬───────────────────────────────────────┘
               │ USB  (flash model_data.h, then serial dump)
               ▼
┌──────────────────────────────────────────────────────┐
│ XIAO RP2040  (Arduino / C++)                         │
│                                                      │
│  INMP441 → audio_features.cpp                        │
│            streaming MFCC → 26-D float32             │
│            ↓                                         │
│  inference.cpp                                       │
│    StandardScaler (SCALER_MEAN / SCALER_SCALE)       │
│    Dense(64,ReLU) → Dense(32,ReLU) → Softmax         │
│    ← all weights from model_data.h                   │
│    ↓  word index / confidence                        │
│  reinforcement.cpp                                   │
│    SENTENCE[] buffer                                 │
│    Q-TABLE[31][31]   ← tabular RL                    │
│    NN_W0[31][16]     ← neural matrix layer 0         │
│    NN_W1[16][31]     ← neural matrix layer 1         │
│    rl_build_response()                               │
│    rl_update()  every tap  +  every second           │
│    rl_serial_dump()  on 10-s button hold             │
│    ↓  response sentence                              │
│  OLED (XIAO_SSD1306_OLED lib)                        │
│    display.write() / clear() / box() / circle()      │
└──────────────────────────────────────────────────────┘
```

---

## Hardware wiring

### OLED SSD1306 (I²C)
| OLED | XIAO RP2040 | GPIO |
|------|-------------|------|
| VCC  | 3V3  | —  |
| GND  | GND  | —  |
| SDA  | D4   | 6  |
| SCL  | D5   | 7  |

*Library default pins — no `pin()` call needed in the sketch.*

### INMP441 (I²S)
| INMP441 | XIAO RP2040 | GPIO | Note |
|---------|-------------|------|------|
| VDD  | 3V3  | —  |              |
| GND  | GND  | —  |              |
| SD   | D10  | 4  | I²S data     |
| SCK  | D8   | 2  | I²S BCLK     |
| WS   | D9   | 3  | LRCLK (auto) |
| L/R  | GND  | —  | Left channel |

### Feedback button
| Button | XIAO RP2040 | Note |
|--------|-------------|------|
| Pin A  | D7 / GPIO 1 | INPUT_PULLUP |
| Pin B  | GND | active LOW |

---

## Step-by-step setup

### 1 — Install Arduino board + library

1. Board Manager → install **arduino-pico** (Earle Philhower III ≥ 3.x).
   Select **"Seeed XIAO RP2040"**.
2. Copy the `XIAO_SSD1306_OLED/` folder into your Arduino `libraries/`
   directory and restart the IDE. *(The sketch folder already contains
   `OLED.h` / `OLED.cpp`, so no separate install step is needed for the sketch.)*

### 2 — Install Python dependencies

```bash
cd word_ai_system
pip install -r requirements.txt
```

### 3 — Collect recordings

```bash
python pc/recorder_ui.py
```

1. Click **"Seed 30 default words"** to add all vocabulary entries.
2. Select a class from the list, or type its ID in the **Quick Record** field.
3. **Hold `R`** → exactly 1 second of audio is captured.
4. **Release `R`** → returns to class-select mode.
5. Aim for **≥ 5 samples per class** for reasonable accuracy.

### 4 — Train the sklearn model

Click **"Train Model"** in `recorder_ui.py`.

Output:
| File | Purpose |
|------|---------|
| `recordings/model.pkl` | Joblib Pipeline for `test_ui.py` |
| `firmware/word_ai/model_data.h` | C float arrays for RP2040 |
| `model_weights.json` | Metadata + weights for `export_model.py` |

The console prints a per-class classification report and cross-validation
accuracy.

### 5 — Flash the firmware

Open `firmware/word_ai/word_ai.ino` in Arduino IDE and click **Upload**.
The sketch includes `model_data.h` automatically.

### 6 — Operate the device

| Action | Effect |
|--------|--------|
| Speak a vocabulary word | OLED shows updated sentence |
| Silence ≥ 2.5 s | AI generates response sentence on OLED |
| **Single tap** button | Good answer → reward +1 → RL trains |
| **Double tap** button | Not good → no reward → RL trains |
| **Hold button 10 s** | Sends CSV dump (Q-table + weights) over USB serial |
| Every second (background) | RL replays last experience → trains more |

### 7 — Live test on PC

```bash
python pc/test_ui.py
```

1. **"Load Model (.pkl) …"** → select `recordings/model.pkl`.
2. Hold `R` to record a word from your microphone.
3. The predicted class name appears at the top; the pie chart shows
   the full softmax probability distribution.
4. Use **"+"** to add extra classes (same workflow as `recorder_ui.py`).

### 8 — Export updated model from RP2040

After the device has been running and training for a while, hold
the button ≥ 10 s.  Then on PC:

```bash
python pc/export_model.py                       # auto-detect USB port
python pc/export_model.py --port /dev/ttyACM0
python pc/export_model.py --port COM3
python pc/export_model.py --file dump.txt       # from saved file
```

Outputs:
| File | Contents |
|------|---------|
| `model_updated.pkl` | Rebuilt sklearn Pipeline |
| `firmware/word_ai/model_data.h` | Regenerated C weight arrays |
| `q_table_dump.npy` | Full Q-table as numpy array |
| `model_updated.tflite` | TFLite model (only if tensorflow installed) |

Flash the new `model_data.h` and re-upload to apply the updated weights.

---

## Feature extraction — PC ↔ Firmware parity

Both `pc/recorder_ui.py` (training on PC) and `firmware/audio_features.cpp`
(inference on RP2040) implement **exactly the same algorithm**:

| Parameter | Value |
|-----------|-------|
| Sample rate | 16 000 Hz |
| Frame size | 256 samples (16 ms) |
| Hop size | 128 samples (50% overlap) |
| Window | Hamming |
| Mel bands | 26 (0 – 8 kHz) |
| MFCC coefficients | 13 (DCT-II, orthonormal) |
| Feature vector | **mean(13) ‖ std(13) = 26-D float32** |

Pre-computed constants (Hamming, Mel filterbank, DCT matrix) live in
`firmware/word_ai/audio_constants.h` and were generated from the same
Python code used at training time.

### sklearn inference in C++

`inference.cpp` implements the full sklearn Pipeline:

```
scaled[i] = (feat[i] - SCALER_MEAN[i]) / SCALER_SCALE[i]
h1[j]     = relu( Σ_i scaled[i] * NN_W0[i][j] + NN_b0[j] )
h2[k]     = relu( Σ_j h1[j]    * NN_W1[j][k] + NN_b1[k] )
out[c]    = softmax( Σ_k h2[k] * NN_W2[k][c] + NN_b2[c] )
```

Maximum deviation from `sklearn.predict_proba()`: ~1e-7 (float32 rounding).

---

## Required Arduino libraries

| Library | Source | Purpose |
|---------|--------|---------|
| **XIAO_SSD1306_OLED** | Provided (zip) | SSD1306 OLED driver |
| **arduino-pico** (≥ 3.x) | Board Manager | RP2040 Arduino core |
| **I2S** | arduino-pico (built-in) | INMP441 microphone |
| **Wire** | arduino-pico (built-in) | I²C for OLED |

---

## Required Python libraries

| Library | Min version | Purpose |
|---------|------------|---------|
| `scikit-learn` | 1.3.0 | `MLPClassifier`, `StandardScaler`, `Pipeline`, CV |
| `numpy` | 1.25.0 (2.x OK) | Array ops, MFCC, weight export |
| `joblib` | 1.3.0 | Pipeline `.pkl` serialisation |
| `sounddevice` | 0.4.6 | PC microphone recording |
| `soundfile` | 0.12.1 | Audio I/O |
| `matplotlib` | 3.7.0 | Pie chart (TkAgg backend) |
| `pyserial` | 3.5 | Serial dump reading |
| `tkinter` | built-in | GUI |
| `tensorflow` | 2.13 *(optional)* | TFLite conversion in `export_model.py` |

All tested on **Python 3.12.3**.
