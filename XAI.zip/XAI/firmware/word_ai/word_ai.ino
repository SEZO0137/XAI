// ============================================================
//  word_ai.ino — Main Sketch
//  Word AI System  |  Seeed XIAO RP2040
// ============================================================
//
//  Hardware connections:
//    ── OLED SSD1306 (library: XIAO_SSD1306_OLED) ───────────
//    SDA → D4  (GPIO 6)    [default — no pin() call needed]
//    SCL → D5  (GPIO 7)
//    VCC → 3.3 V
//    GND → GND
//
//    ── INMP441 I2S Microphone ───────────────────────────────
//    SD  → D10 (GPIO 4)   [I2S data]
//    SCK → D8  (GPIO 2)   [I2S BCLK]
//    WS  → D9  (GPIO 3)   [I2S LRCLK — auto: BCLK+1]
//    L/R → GND             [select left channel]
//    VDD → 3.3 V
//    GND → GND
//
//    ── Feedback button ──────────────────────────────────────
//    One side → D7 (GPIO 1)
//    Other    → GND
//    (Internal pull-up enabled — active LOW)
//
//  ── Required Arduino libraries ─────────────────────────────
//    • XIAO_SSD1306_OLED  (provided — copy to Arduino/libraries)
//    • arduino-pico core  (Earle Philhower III, v3.x)
//      Board: "Seeed XIAO RP2040"
//      Includes: I2S, Wire
//
//  ── Behaviour overview ───────────────────────────────────────
//    1. Continuously poll for voice activity (VAD).
//    2. On voice detected: record exactly 1 second from INMP441,
//       extract 26-D MFCC features, run the dense-network classifier.
//    3. Detected word ID is stored in detected_word_id.
//       Word index is appended to SENTENCE[].
//    4. The heard sentence is displayed on the OLED.
//    5. After silence (no new word for RESPONSE_DELAY_MS),
//       the RL agent builds a response sentence and shows it.
//    6. Button feedback:
//         Single tap  → reward +1  → rl_update()
//         Double tap  → no reward  → rl_update() with 0
//    7. Every second: rl_periodic_update() to replay last experience.
//    8. Button held ≥ 10 s → rl_serial_dump() over USB serial.
// ============================================================

#include <Wire.h>
#include "OLED.h"
#include "audio_features.h"
#include "inference.h"
#include "reinforcement.h"
#include "model_data.h"

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Pin assignments
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#define BUTTON_PIN        1     // GPIO 1 = D7

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Timing constants
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
#define DOUBLE_TAP_WINDOW_MS   500   // two taps within 500 ms = double
#define SINGLE_TAP_MAX_MS      400   // press+release < 400 ms = tap
#define HOLD_DUMP_MS         10000   // held ≥ 10 s → serial dump
#define RL_PERIODIC_MS        1000   // neural net replay every 1 s
#define RESPONSE_DELAY_MS     2500   // silence gap before generating response
#define OLED_WRAP_CHARS         21   // chars per OLED line (128px ÷ 6px/char)

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Global objects
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
oled display;                // OLED SSD1306 — using the provided library

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Application state
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static int    detected_word_id  = -1;   // last recognised word's external ID
static int    detected_word_idx = -1;   // last recognised word's vocab index
static float  detected_conf     = 0.0f; // last recognition confidence

static bool   in_listening_mode    = true;  // true = showing heard sentence
static bool   response_displayed   = false; // true = showing AI response
static unsigned long last_word_ms  = 0;     // millis() of last recognised word
static unsigned long rl_periodic_ms = 0;    // millis() of last RL periodic step

// ── Button state machine ──────────────────────────────────────
enum ButtonEvent { BTN_NONE, BTN_SINGLE_TAP, BTN_DOUBLE_TAP, BTN_HOLD_DUMP };

static bool          _btn_was_pressed     = false;
static unsigned long _btn_press_ms        = 0;
static unsigned long _btn_release_ms      = 0;
static int           _btn_tap_count       = 0;
static unsigned long _btn_first_tap_ms    = 0;

// ── RL feedback tracking ─────────────────────────────────────
static bool  _waiting_for_feedback = false;
static int   _feedback_state       = SILENCE_STATE;
static int   _feedback_action      = STOP_ACTION;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  OLED helpers
//  Uses the XIAO_SSD1306_OLED library exactly as documented:
//    o.clear(); o.write(x, y, str); o.display();
//    o.box(x1,y1,x2,y2); o.brightness(level);
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Word-wrap a string onto the OLED starting at (x, y).
// Each line fits OLED_WRAP_CHARS characters (21 @ 6 px/char).
// Uses display.write() which calls display() internally.
static void oled_print_wrapped(const char* text, int y_start) {
    char line[OLED_WRAP_CHARS + 1];
    int  len   = strlen(text);
    int  start = 0;
    int  y     = y_start;

    while (start < len && y < 64) {
        int end = start + OLED_WRAP_CHARS;
        if (end > len) end = len;

        // Try to break at a space
        if (end < len && text[end] != ' ') {
            int space = end;
            while (space > start && text[space] != ' ') space--;
            if (space > start) end = space;
        }

        int n = end - start;
        memcpy(line, text + start, n);
        line[n] = '\0';
        display.write(0, y, line);   // OLED library call
        y    += 8;   // CHAR_H = 8 px
        start = end;
        if (start < len && text[start] == ' ') start++;
    }
}

// Show the heard sentence on OLED
static void oled_show_sentence() {
    char sentence_buf[80];
    sentence_to_str(sentence_buf, sizeof(sentence_buf));

    display.clear();
    display.write(0, 0,  "You said:");         // row 0
    display.box(0, 8, 127, 9);                 // separator line
    oled_print_wrapped(sentence_buf, 10);       // rows 10+
    display.write(0, 56, "Listening...");       // row 56 (bottom)
}

// Show the AI response on OLED
static void oled_show_response() {
    char response_buf[80];
    response_to_str(response_buf, sizeof(response_buf));

    display.clear();
    display.write(0, 0,  "AI says:");           // row 0
    display.box(0, 8, 127, 9);                  // separator line
    oled_print_wrapped(response_buf, 10);        // rows 10+
    display.write(0, 48, "1tap=good 2tap=bad"); // feedback hint row 48
    display.write(0, 56, "Hold 10s=dump");      // dump hint row 56
}

// Show a status / boot screen
static void oled_show_status(const char* line1, const char* line2) {
    display.clear();
    display.write(0,  0, line1);
    display.write(0,  8, line2);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Button event detection
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static ButtonEvent poll_button() {
    bool pressed = (digitalRead(BUTTON_PIN) == LOW);
    unsigned long now = millis();

    if (pressed && !_btn_was_pressed) {
        // Rising edge: button just pressed
        _btn_press_ms    = now;
        _btn_was_pressed = true;
    }
    else if (!pressed && _btn_was_pressed) {
        // Falling edge: button just released
        unsigned long hold = now - _btn_press_ms;
        _btn_was_pressed   = false;

        if (hold >= HOLD_DUMP_MS) {
            // Long hold → dump event (return immediately)
            _btn_tap_count   = 0;
            return BTN_HOLD_DUMP;
        }

        if (hold < SINGLE_TAP_MAX_MS) {
            // Short press = tap
            _btn_tap_count++;
            if (_btn_tap_count == 1) {
                _btn_first_tap_ms = now;
            }
        }
        _btn_release_ms = now;
    }
    else if (_btn_was_pressed && (now - _btn_press_ms >= HOLD_DUMP_MS)) {
        // Still held past 10 s threshold → dump immediately
        _btn_was_pressed = false;
        _btn_tap_count   = 0;
        return BTN_HOLD_DUMP;
    }

    // Resolve tap count after double-tap window expires
    if (_btn_tap_count > 0 && (now - _btn_first_tap_ms > DOUBLE_TAP_WINDOW_MS)) {
        int taps       = _btn_tap_count;
        _btn_tap_count = 0;
        if (taps >= 2)  return BTN_DOUBLE_TAP;
        if (taps == 1)  return BTN_SINGLE_TAP;
    }

    return BTN_NONE;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Handle button feedback from the user
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void handle_feedback(bool good) {
    if (!_waiting_for_feedback) return;

    float reward = good ? 1.0f : 0.0f;
    int   next_s = SILENCE_STATE;

    rl_update(_feedback_state, _feedback_action, reward, next_s);

    _waiting_for_feedback = false;
    _feedback_state  = SILENCE_STATE;
    _feedback_action = STOP_ACTION;

    // Acknowledge on OLED
    display.clear();
    display.write(0,  0, good ? "Reward: GOOD" : "Reward: NONE");
    display.write(0,  8, "Training...");
    // (display is automatically pushed by each display.write() call)
    delay(700);

    // Return to listening mode after feedback
    oled_show_sentence();
    in_listening_mode  = true;
    response_displayed = false;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Voice detection + word recognition
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void handle_voice_detection() {
    if (!audio_detect_voice()) return;

    // Voice onset detected — show recording indicator on OLED
    display.clear();
    display.write(0,  0, "Recording...");
    display.circle(64, 38, 12);   // draw circle as visual indicator

    // Record exactly 1 second and extract features
    float features[AUDIO_INPUT_DIM];
    if (!audio_record_and_extract(features)) {
        oled_show_status("Audio error", "Check I2S wiring");
        return;
    }

    // Run the dense-network classifier
    InferenceResult res;
    inference_run(features, &res);

    detected_word_id  = res.class_id;
    detected_word_idx = vocab_index(res.class_id);
    detected_conf     = res.confidence;

    // Only accept if confidence is meaningful
    if (res.confidence < 0.35f) {
        // Too uncertain — ignore
        oled_show_sentence();
        return;
    }

    // Add to sentence buffer
    if (detected_word_idx >= 0) {
        sentence_add_word(detected_word_idx);
        last_word_ms       = millis();
        in_listening_mode  = true;
        response_displayed = false;
        _waiting_for_feedback = false;
    }

    // Refresh OLED with updated sentence
    oled_show_sentence();

    // Print to serial for debugging
    Serial.print("[WORD] id=");    Serial.print(detected_word_id);
    Serial.print(" word=");        Serial.print(vocab_word(detected_word_idx));
    Serial.print(" conf=");        Serial.println(detected_conf, 3);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Generate AI response after silence gap
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void handle_response_generation() {
    if (!in_listening_mode)  return;
    if (response_displayed)  return;
    if (SENTENCE_LEN == 0)   return;

    unsigned long now = millis();
    if (now - last_word_ms < RESPONSE_DELAY_MS) return;  // still listening

    // Build RL response using the full sentence context
    rl_build_response(SENTENCE, SENTENCE_LEN);

    // Store state/action for later feedback
    _feedback_state  = RL_LAST_STATE;
    _feedback_action = RL_LAST_ACTION;
    _waiting_for_feedback = (RESPONSE_LEN > 0);

    // Show response on OLED
    oled_show_response();
    in_listening_mode  = false;
    response_displayed = true;

    // Debug print
    char response_buf[80];
    response_to_str(response_buf, sizeof(response_buf));
    Serial.print("[RESP] "); Serial.println(response_buf);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Serial dump on 10-second hold
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void handle_serial_dump() {
    display.clear();
    display.write(0,  0, "Sending dump...");
    display.write(0,  8, "Keep USB conn.");
    display.write(0, 16, "Wait ~10 s");

    Serial.println();
    Serial.println("== WORD AI DUMP START ==");
    rl_serial_dump(N_CLASSES, INPUT_DIM, CLASS_IDS, CLASS_NAMES);
    Serial.println("== WORD AI DUMP END ==");
    Serial.flush();

    display.clear();
    display.write(0,  0, "Dump sent!");
    display.write(0,  8, "See serial port.");
    delay(2000);
    oled_show_sentence();
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  setup()
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void setup() {
    Serial.begin(115200);

    // ── Button pin ───────────────────────────────────────────
    pinMode(BUTTON_PIN, INPUT_PULLUP);

    // ── OLED init (lazy auto-init on first use per library docs)
    // Default pins D4=SDA, D5=SCL — no pin() call needed.
    // Show boot splash.
    display.write(0,  0, "Word AI v1.0");
    display.write(0,  8, "XIAO RP2040");
    display.write(0, 16, "Initialising...");

    // ── I2S microphone init ───────────────────────────────────
    display.clear();
    display.write(0, 0, "Init mic...");
    if (!audio_init()) {
        display.write(0, 8, "I2S FAILED!");
        display.write(0, 16,"Check INMP441.");
        // Halt — cannot proceed without microphone
        while (true) { delay(1000); }
    }
    display.write(0, 8, "Mic OK");

    // ── RL init ───────────────────────────────────────────────
    display.write(0, 16, "Init RL...");
    rl_init();
    display.write(0, 24, "RL OK");

    // ── Measure noise floor for dynamic VAD ───────────────────
    display.write(0, 32, "Noise floor...");
    float noise = audio_measure_noise_floor();
    Serial.print("[AUDIO] Noise floor: "); Serial.println(noise, 5);

    delay(500);

    // ── Ready splash ──────────────────────────────────────────
    display.clear();
    display.write( 0,  0, "Word AI Ready!");
    display.write( 0,  8, "Say a word.");
    display.write( 0, 16, "Hold 10s=dump");
    display.box(0, 26, 127, 44);
    display.write( 6, 28, "1-tap: good");
    display.write( 6, 36, "2-tap: bad");
    delay(2000);

    // ── Initial OLED state: listening ────────────────────────
    oled_show_sentence();

    last_word_ms    = millis();
    rl_periodic_ms  = millis();
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  loop()
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void loop() {
    unsigned long now = millis();

    // ── 1. Poll button ────────────────────────────────────────
    ButtonEvent btn = poll_button();
    switch (btn) {
        case BTN_SINGLE_TAP:
            handle_feedback(true);   // good answer — reward
            break;

        case BTN_DOUBLE_TAP:
            handle_feedback(false);  // not good — no reward
            break;

        case BTN_HOLD_DUMP:
            handle_serial_dump();
            break;

        default:
            break;
    }

    // ── 2. Periodic RL training (every second) ────────────────
    if (now - rl_periodic_ms >= RL_PERIODIC_MS) {
        rl_periodic_ms = now;
        rl_periodic_update();
    }

    // ── 3. Generate response after silence gap ────────────────
    //    (only when in listening mode and response not yet shown)
    handle_response_generation();

    // ── 4. Detect voice and recognise word ────────────────────
    //    This function blocks for ~1 second when voice is active.
    //    When no voice is detected, audio_detect_voice() reads
    //    just N_FFT (256) samples (~16 ms) and returns quickly.
    if (in_listening_mode || !response_displayed) {
        handle_voice_detection();
    }

    // ── 5. When new word arrives while response is showing ────
    //    New speech resets the conversation.
    if (!in_listening_mode && audio_detect_voice()) {
        // User started talking again — clear sentence and listen
        sentence_clear();
        in_listening_mode  = true;
        response_displayed = false;
        _waiting_for_feedback = false;
        oled_show_sentence();
        handle_voice_detection();
    }
}
