// ============================================================
//  reinforcement.cpp — Q-Table + Neural Matrix RL
//  Word AI  |  Seeed XIAO RP2040
// ============================================================

#include "reinforcement.h"
#include <Arduino.h>
#include <math.h>
#include <string.h>
#include <stdlib.h>

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Vocabulary table — 30 words that can form sentences
//  Must exactly match DEFAULT_WORDS in Python scripts
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
const char* const VOCAB[VOCAB_SIZE] = {
    "yes",   "no",    "hello", "bye",   "I",
    "you",   "want",  "need",  "help",  "what",
    "how",   "where", "when",  "good",  "bad",
    "please","thank", "stop",  "go",    "here",
    "there", "more",  "less",  "up",    "down",
    "left",  "right", "on",    "off",   "okay"
};

// External integer IDs (must match CLASS_IDS in model_data.h / Python)
const int VOCAB_IDS[VOCAB_SIZE] = {
     1,  2,  3,  4,  5,
     6,  7,  8,  9, 10,
    11, 12, 13, 14, 15,
    16, 17, 18, 19, 20,
    21, 22, 23, 24, 25,
    26, 27, 28, 29, 30
};

// ── Global RL state ──────────────────────────────────────────
float Q_TABLE[N_STATES][N_ACTIONS];

// Neural matrices — layer 0 (input → hidden)
float NN_W0[NN_INPUT][NN_HIDDEN];
float NN_b0[NN_HIDDEN];

// Neural matrices — layer 1 (hidden → output)
float NN_W1[NN_HIDDEN][NN_OUTPUT];
float NN_b1[NN_OUTPUT];

// Sentence / response buffers
int SENTENCE[MAX_SENTENCE_LEN];
int SENTENCE_LEN = 0;

int RESPONSE[MAX_RESPONSE_LEN];
int RESPONSE_LEN = 0;

int RL_LAST_STATE  = SILENCE_STATE;
int RL_LAST_ACTION = STOP_ACTION;

// ── Internal experience replay buffer (size 1 — last event) ──
static float  _last_reward    = 0.0f;
static int    _last_next_state = SILENCE_STATE;
static bool   _has_experience  = false;

// ── Working arrays for forward pass ──────────────────────────
static float _h0[NN_HIDDEN];   // hidden activations
static float _a0[NN_HIDDEN];   // pre-activation hidden
static float _out[NN_OUTPUT];  // output Q-values

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Internal helpers
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static inline float _relu(float x) { return x > 0.0f ? x : 0.0f; }
static inline float _relu_d(float pre) { return pre > 0.0f ? 1.0f : 0.0f; }

// Random float in [0, 1)
static float _randf() {
    return (float)(random(0, 32767)) / 32767.0f;
}

// ── Neural network forward pass ──────────────────────────────
// input: one-hot vector of size NN_INPUT (= N_STATES)
// Fills _h0, _a0, _out (all module-level arrays)
static void _nn_forward(const float* input) {
    // Layer 0: hidden = relu(W0^T @ input + b0)
    for (int j = 0; j < NN_HIDDEN; j++) {
        float sum = NN_b0[j];
        for (int i = 0; i < NN_INPUT; i++) {
            sum += input[i] * NN_W0[i][j];
        }
        _a0[j] = sum;
        _h0[j] = _relu(sum);
    }
    // Layer 1: output = relu(W1^T @ h0 + b1)
    for (int k = 0; k < NN_OUTPUT; k++) {
        float sum = NN_b1[k];
        for (int j = 0; j < NN_HIDDEN; j++) {
            sum += _h0[j] * NN_W1[j][k];
        }
        _out[k] = _relu(sum);   // Q-values — no softmax
    }
}

// ── One-hot encode state into input vector ────────────────────
static void _one_hot(int state, float* vec) {
    memset(vec, 0, sizeof(float) * NN_INPUT);
    if (state >= 0 && state < NN_INPUT) {
        vec[state] = 1.0f;
    }
}

// ── Q-value from neural network for (state, action) ──────────
static float _q_nn(int state, int action) {
    float input[NN_INPUT];
    _one_hot(state, input);
    _nn_forward(input);
    return _out[action];
}

// ── Max Q-value over all actions for a state ─────────────────
static float _max_q(int state) {
    float input[NN_INPUT];
    _one_hot(state, input);
    _nn_forward(input);

    float q_max_nn  = _out[0];
    float q_max_tab = Q_TABLE[state][0];

    for (int a = 1; a < N_ACTIONS; a++) {
        if (_out[a]             > q_max_nn)  q_max_nn  = _out[a];
        if (Q_TABLE[state][a]  > q_max_tab) q_max_tab = Q_TABLE[state][a];
    }
    return q_max_tab * (1.0f - Q_NN_WEIGHT) + q_max_nn * Q_NN_WEIGHT;
}

// ── Basic sentence knowledge — seeded Q-table priors ─────────
// Higher initial Q values for grammatically plausible transitions
// Indices: 0=yes,1=no,2=hello,3=bye,4=I,5=you,6=want,7=need,
//          8=help,9=what,10=how,11=where,12=when,13=good,14=bad,
//          15=please,16=thank,17=stop,18=go,19=here,20=there,
//          21=more,22=less,23=up,24=down,25=left,26=right,27=on,
//          28=off,29=okay, 30=STOP
static void _seed_grammar() {
    // After "I"  → want/need/go/help are likely
    Q_TABLE[4][6]  = 0.40f;  // I → want
    Q_TABLE[4][7]  = 0.40f;  // I → need
    Q_TABLE[4][18] = 0.30f;  // I → go
    Q_TABLE[4][8]  = 0.25f;  // I → help

    // After "you" → want/need/go
    Q_TABLE[5][6]  = 0.35f;  // you → want
    Q_TABLE[5][7]  = 0.30f;  // you → need
    Q_TABLE[5][9]  = 0.30f;  // you → what

    // After "want/need" → more/help/here/there
    Q_TABLE[6][21] = 0.35f;  // want → more
    Q_TABLE[6][8]  = 0.30f;  // want → help
    Q_TABLE[7][21] = 0.35f;  // need → more
    Q_TABLE[7][8]  = 0.30f;  // need → help

    // After "go" → here/there/up/down/left/right
    Q_TABLE[18][19] = 0.40f; // go → here
    Q_TABLE[18][20] = 0.35f; // go → there
    Q_TABLE[18][23] = 0.30f; // go → up
    Q_TABLE[18][24] = 0.30f; // go → down

    // After "hello" → hello/you/good
    Q_TABLE[2][5]  = 0.45f;  // hello → you
    Q_TABLE[2][13] = 0.30f;  // hello → good

    // After "good" → yes/okay
    Q_TABLE[13][0]  = 0.40f; // good → yes
    Q_TABLE[13][29] = 0.35f; // good → okay

    // After "what"/"how" → more/help/good
    Q_TABLE[9][21]  = 0.30f; // what → more
    Q_TABLE[10][13] = 0.30f; // how → good

    // After "please"/"thank" → stop action (short polite replies)
    Q_TABLE[15][STOP_ACTION] = 0.50f; // please → stop
    Q_TABLE[16][0]  = 0.40f;          // thank → yes
    Q_TABLE[16][13] = 0.35f;          // thank → good

    // Silence state → greeting is likely
    Q_TABLE[SILENCE_STATE][2]  = 0.30f; // silence → hello
    Q_TABLE[SILENCE_STATE][0]  = 0.20f; // silence → yes
    Q_TABLE[SILENCE_STATE][13] = 0.20f; // silence → good
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_init
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void rl_init() {
    randomSeed(analogRead(A0) ^ micros());

    // ── Q-table: small uniform random baseline ────────────────
    for (int s = 0; s < N_STATES; s++) {
        for (int a = 0; a < N_ACTIONS; a++) {
            Q_TABLE[s][a] = 0.01f * _randf();
        }
    }

    // ── Neural matrices: Xavier uniform ──────────────────────
    // Layer 0
    float lim0 = sqrtf(6.0f / (NN_INPUT + NN_HIDDEN));
    for (int i = 0; i < NN_INPUT; i++) {
        for (int j = 0; j < NN_HIDDEN; j++) {
            NN_W0[i][j] = (_randf() * 2.0f - 1.0f) * lim0;
        }
    }
    memset(NN_b0, 0, sizeof(NN_b0));

    // Layer 1
    float lim1 = sqrtf(6.0f / (NN_HIDDEN + NN_OUTPUT));
    for (int j = 0; j < NN_HIDDEN; j++) {
        for (int k = 0; k < NN_OUTPUT; k++) {
            NN_W1[j][k] = (_randf() * 2.0f - 1.0f) * lim1;
        }
    }
    memset(NN_b1, 0, sizeof(NN_b1));

    // ── Seed grammar-based Q-table priors ────────────────────
    _seed_grammar();

    // ── Sentence / response buffers ───────────────────────────
    sentence_clear();
    RESPONSE_LEN = 0;
    for (int i = 0; i < MAX_RESPONSE_LEN; i++) RESPONSE[i] = -1;

    RL_LAST_STATE  = SILENCE_STATE;
    RL_LAST_ACTION = STOP_ACTION;
    _has_experience = false;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_select_action
//  Epsilon-greedy using combined Q (table + neural)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
int rl_select_action(int state) {
    // ε-greedy exploration
    if (_randf() < RL_EPSILON) {
        return (int)(random(0, N_ACTIONS));
    }

    float input[NN_INPUT];
    _one_hot(state, input);
    _nn_forward(input);  // fills _out[]

    int best_a    = 0;
    float best_q  = -1e9f;

    for (int a = 0; a < N_ACTIONS; a++) {
        float combined = Q_TABLE[state][a] * (1.0f - Q_NN_WEIGHT)
                       + _out[a]            *        Q_NN_WEIGHT;
        if (combined > best_q) {
            best_q = combined;
            best_a = a;
        }
    }
    return best_a;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_build_response
//  Build RESPONSE[] for the heard sentence.
//  If max Q < threshold → jumble random words.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void rl_build_response(const int* heard_indices, int heard_len) {
    RESPONSE_LEN = 0;

    // Use the last heard word as the initial state for the RL chain
    int state = SILENCE_STATE;
    if (heard_len > 0) {
        int last_word = heard_indices[heard_len - 1];
        if (last_word >= 0 && last_word < VOCAB_SIZE) {
            state = last_word;
        }
    }

    // Check whether the RL agent has a confident answer
    float input[NN_INPUT];
    _one_hot(state, input);
    _nn_forward(input);

    float max_q_combined = 0.0f;
    for (int a = 0; a < N_ACTIONS; a++) {
        float cq = Q_TABLE[state][a] * (1.0f - Q_NN_WEIGHT) + _out[a] * Q_NN_WEIGHT;
        if (cq > max_q_combined) max_q_combined = cq;
    }

    bool has_answer = (max_q_combined >= Q_LOW_THRESH);

    if (has_answer) {
        // ── Structured RL-driven response ────────────────────
        int cur_state = state;
        for (int t = 0; t < MAX_RESPONSE_LEN; t++) {
            int action = rl_select_action(cur_state);
            if (action == STOP_ACTION) break;
            RESPONSE[RESPONSE_LEN++] = action;

            // Store last (state, action) for TD update after feedback
            RL_LAST_STATE  = cur_state;
            RL_LAST_ACTION = action;

            cur_state = action;   // transition: next state = emitted word
        }
    } else {
        // ── Jumble: randomly select 2-4 words ───────────────
        int n_words = 2 + (int)(random(0, 3));  // 2, 3, or 4 words
        // Shuffle indices
        int pool[VOCAB_SIZE];
        for (int i = 0; i < VOCAB_SIZE; i++) pool[i] = i;
        // Fisher-Yates shuffle (first n_words positions)
        for (int i = 0; i < n_words && i < VOCAB_SIZE; i++) {
            int j = i + (int)(random(0, VOCAB_SIZE - i));
            int tmp = pool[i]; pool[i] = pool[j]; pool[j] = tmp;
        }
        for (int i = 0; i < n_words; i++) {
            RESPONSE[RESPONSE_LEN++] = pool[i];
        }
        // Record last action for feedback update
        if (n_words > 0) {
            RL_LAST_STATE  = state;
            RL_LAST_ACTION = pool[0];
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_update
//  TD(0) update for Q-table AND one gradient step on neural net
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void rl_update(int state, int action, float reward, int next_state) {
    if (state  < 0 || state  >= N_STATES)  return;
    if (action < 0 || action >= N_ACTIONS) return;
    if (next_state < 0 || next_state >= N_STATES) next_state = SILENCE_STATE;

    // ── Q-table TD update ────────────────────────────────────
    float q_next  = _max_q(next_state);
    float td_target = reward + RL_GAMMA * q_next;
    float td_error  = td_target - Q_TABLE[state][action];
    Q_TABLE[state][action] += RL_ALPHA * td_error;
    // Clamp to reasonable range
    if (Q_TABLE[state][action] < 0.0f) Q_TABLE[state][action] = 0.0f;
    if (Q_TABLE[state][action] > 1.0f) Q_TABLE[state][action] = 1.0f;

    // ── Neural network gradient step ─────────────────────────
    // Forward pass
    float input[NN_INPUT];
    _one_hot(state, input);
    _nn_forward(input);   // fills _h0, _a0, _out

    // Output error: only update the taken action's output neuron
    // Use td_target as the supervision signal for Q_nn(s, action)
    float delta1[NN_OUTPUT];
    memset(delta1, 0, sizeof(delta1));
    delta1[action] = td_target - _out[action];

    // ── Backprop: Layer 1 gradients ───────────────────────────
    // dW1[j][k] = delta1[k] * h0[j]
    // db1[k]    = delta1[k]
    for (int j = 0; j < NN_HIDDEN; j++) {
        for (int k = 0; k < NN_OUTPUT; k++) {
            NN_W1[j][k] += NN_LR * delta1[k] * _h0[j];
        }
    }
    for (int k = 0; k < NN_OUTPUT; k++) {
        NN_b1[k] += NN_LR * delta1[k];
    }

    // ── Backprop: Layer 0 gradients ───────────────────────────
    // delta0[j] = (sum_k delta1[k] * W1[j][k]) * relu'(a0[j])
    // dW0[i][j] = delta0[j] * input[i]
    // db0[j]    = delta0[j]
    float delta0[NN_HIDDEN];
    for (int j = 0; j < NN_HIDDEN; j++) {
        float sum = 0.0f;
        for (int k = 0; k < NN_OUTPUT; k++) {
            sum += delta1[k] * NN_W1[j][k];
        }
        delta0[j] = sum * _relu_d(_a0[j]);
    }
    for (int i = 0; i < NN_INPUT; i++) {
        for (int j = 0; j < NN_HIDDEN; j++) {
            NN_W0[i][j] += NN_LR * delta0[j] * input[i];
        }
    }
    for (int j = 0; j < NN_HIDDEN; j++) {
        NN_b0[j] += NN_LR * delta0[j];
    }

    // Store experience for periodic replay
    _last_reward     = reward;
    _last_next_state = next_state;
    _has_experience  = true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_periodic_update
//  Called every second — replay last experience for extra training
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void rl_periodic_update() {
    if (!_has_experience) return;
    rl_update(RL_LAST_STATE, RL_LAST_ACTION, _last_reward, _last_next_state);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Sentence buffer helpers
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void sentence_add_word(int word_idx) {
    if (word_idx < 0 || word_idx >= VOCAB_SIZE) return;
    if (SENTENCE_LEN >= MAX_SENTENCE_LEN) {
        // Shift left to make room
        for (int i = 0; i < MAX_SENTENCE_LEN - 1; i++) {
            SENTENCE[i] = SENTENCE[i + 1];
        }
        SENTENCE[MAX_SENTENCE_LEN - 1] = word_idx;
    } else {
        SENTENCE[SENTENCE_LEN++] = word_idx;
    }
}

void sentence_clear() {
    SENTENCE_LEN = 0;
    for (int i = 0; i < MAX_SENTENCE_LEN; i++) SENTENCE[i] = -1;
}

void sentence_to_str(char* buf, int buf_len) {
    buf[0] = '\0';
    int pos = 0;
    for (int i = 0; i < SENTENCE_LEN && pos < buf_len - 2; i++) {
        if (i > 0 && pos < buf_len - 2) { buf[pos++] = ' '; }
        const char* w = vocab_word(SENTENCE[i]);
        for (int c = 0; w[c] && pos < buf_len - 1; c++) buf[pos++] = w[c];
    }
    buf[pos] = '\0';
}

void response_to_str(char* buf, int buf_len) {
    buf[0] = '\0';
    int pos = 0;
    for (int i = 0; i < RESPONSE_LEN && pos < buf_len - 2; i++) {
        if (i > 0 && pos < buf_len - 2) { buf[pos++] = ' '; }
        const char* w = vocab_word(RESPONSE[i]);
        for (int c = 0; w[c] && pos < buf_len - 1; c++) buf[pos++] = w[c];
    }
    buf[pos] = '\0';
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Vocabulary helpers
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
int vocab_id(int idx) {
    if (idx < 0 || idx >= VOCAB_SIZE) return -1;
    return VOCAB_IDS[idx];
}

int vocab_index(int id) {
    for (int i = 0; i < VOCAB_SIZE; i++) {
        if (VOCAB_IDS[i] == id) return i;
    }
    return -1;
}

const char* vocab_word(int idx) {
    if (idx < 0 || idx >= VOCAB_SIZE) return "?";
    return VOCAB[idx];
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  rl_serial_dump
//  Emits Q-table + neural matrices as CSV over Serial
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void rl_serial_dump(int n_classes, int input_dim,
                    const int* class_ids, const char* const* class_names)
{
    // ── META JSON line ────────────────────────────────────────
    Serial.print("##META## {");
    Serial.print("\"n_classes\":");   Serial.print(n_classes);
    Serial.print(",\"input_dim\":");  Serial.print(input_dim);
    Serial.print(",\"n_states\":");   Serial.print(N_STATES);
    Serial.print(",\"n_actions\":");  Serial.print(N_ACTIONS);
    Serial.print(",\"cid_list\":[");
    for (int i = 0; i < n_classes; i++) {
        if (i) Serial.print(",");
        Serial.print(class_ids[i]);
    }
    Serial.print("],\"classes\":{");
    for (int i = 0; i < n_classes; i++) {
        if (i) Serial.print(",");
        Serial.print("\""); Serial.print(class_ids[i]); Serial.print("\"");
        Serial.print(":\""); Serial.print(class_names[i]); Serial.print("\"");
    }
    Serial.println("}}");

    delay(20);

    // ── Q-table ───────────────────────────────────────────────
    Serial.println("##QTABLE_START##");
    for (int s = 0; s < N_STATES; s++) {
        for (int a = 0; a < N_ACTIONS; a++) {
            Serial.print(Q_TABLE[s][a], 6);
            if (a < N_ACTIONS - 1) Serial.print(",");
        }
        Serial.println();
        delay(1);   // avoid Serial buffer overflow
    }
    Serial.println("##QTABLE_END##");

    delay(20);

    // ── Neural weights ────────────────────────────────────────
    // Each row = output neuron: bias, w[i][0], w[i][1], ...
    Serial.println("##WEIGHTS_START##");

    // Layer 0: NN_INPUT → NN_HIDDEN  (NN_HIDDEN rows)
    Serial.println("##LAYER## 0");
    for (int j = 0; j < NN_HIDDEN; j++) {
        Serial.print(NN_b0[j], 6);
        for (int i = 0; i < NN_INPUT; i++) {
            Serial.print(",");
            Serial.print(NN_W0[i][j], 6);
        }
        Serial.println();
        delay(1);
    }

    // Layer 1: NN_HIDDEN → NN_OUTPUT  (NN_OUTPUT rows)
    Serial.println("##LAYER## 1");
    for (int k = 0; k < NN_OUTPUT; k++) {
        Serial.print(NN_b1[k], 6);
        for (int j = 0; j < NN_HIDDEN; j++) {
            Serial.print(",");
            Serial.print(NN_W1[j][k], 6);
        }
        Serial.println();
        delay(1);
    }

    Serial.println("##WEIGHTS_END##");
    Serial.flush();
}
