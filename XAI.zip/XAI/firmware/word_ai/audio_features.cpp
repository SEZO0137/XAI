// ============================================================
//  audio_features.cpp — INMP441 I2S + MFCC Feature Extraction
//  Word AI  |  Seeed XIAO RP2040
// ============================================================

#include "audio_features.h"
#include "audio_constants.h"
#include <math.h>
#include <string.h>

// ── Module-level I2S object ──────────────────────────────────
static I2S _i2s(INPUT);
static bool _i2s_ready = false;

// ── Working buffers (allocated once to avoid stack overflow) ──
// Two half-frames: current and previous for 50% overlap
static float _frame[AUDIO_N_FFT];       // windowed time-domain frame
static float _fft_re[AUDIO_N_FFT];      // real part for in-place FFT
static float _fft_im[AUDIO_N_FFT];      // imaginary part
static float _power[AUDIO_N_BINS];      // |FFT|^2 / N
static float _mel[AUDIO_N_MELS];        // Mel energies
static float _log_mel[AUDIO_N_MELS];    // log Mel energies
static float _mfcc_frame[AUDIO_N_MFCC]; // per-frame MFCC

// Accumulators for computing mean+std online
static float _mfcc_sum[AUDIO_N_MFCC];
static float _mfcc_sum2[AUDIO_N_MFCC];
static int   _n_frames_acc;

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Bit-reversal permutation for Cooley–Tukey FFT (N=256)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void _bit_reverse(float* re, float* im, int n) {
    int j = 0;
    for (int i = 1; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) { j ^= bit; }
        j ^= bit;
        if (i < j) {
            float tr = re[i]; re[i] = re[j]; re[j] = tr;
            float ti = im[i]; im[i] = im[j]; im[j] = ti;
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  In-place radix-2 DIT FFT  (N must be power of 2)
//  Fills re[] and im[] with the complex DFT.
//  Uses the built-in sinf/cosf which are hardware-accelerated
//  on RP2040.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void _fft(float* re, float* im, int n) {
    _bit_reverse(re, im, n);

    for (int len = 2; len <= n; len <<= 1) {
        float ang = -2.0f * (float)M_PI / (float)len;
        float wRe = cosf(ang);
        float wIm = sinf(ang);

        for (int i = 0; i < n; i += len) {
            float curRe = 1.0f, curIm = 0.0f;
            int half = len >> 1;

            for (int j = 0; j < half; j++) {
                float uRe = re[i + j];
                float uIm = im[i + j];
                float vRe = re[i + j + half] * curRe - im[i + j + half] * curIm;
                float vIm = re[i + j + half] * curIm + im[i + j + half] * curRe;

                re[i + j]        = uRe + vRe;
                im[i + j]        = uIm + vIm;
                re[i + j + half] = uRe - vRe;
                im[i + j + half] = uIm - vIm;

                // Rotate twiddle factor
                float tmpRe = curRe * wRe - curIm * wIm;
                curIm       = curRe * wIm + curIm * wRe;
                curRe       = tmpRe;
            }
        }
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Process one 256-sample frame and add its MFCC to accumulators
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
static void _process_frame(const float* frame) {
    // ── Apply Hamming window ──────────────────────────────────
    for (int n = 0; n < AUDIO_N_FFT; n++) {
        _fft_re[n] = frame[n] * HAMMING_WIN[n];
        _fft_im[n] = 0.0f;
    }

    // ── FFT ───────────────────────────────────────────────────
    _fft(_fft_re, _fft_im, AUDIO_N_FFT);

    // ── Power spectrum: |X[k]|^2 / N  (only first N/2+1 bins) ─
    for (int k = 0; k < AUDIO_N_BINS; k++) {
        _power[k] = (_fft_re[k] * _fft_re[k] + _fft_im[k] * _fft_im[k])
                    / (float)AUDIO_N_FFT;
    }

    // ── Mel filterbank: mel[m] = sum_k power[k] * MEL_FB[m][k] ─
    for (int m = 0; m < AUDIO_N_MELS; m++) {
        float sum = 0.0f;
        for (int k = 0; k < AUDIO_N_BINS; k++) {
            sum += _power[k] * MEL_FB[m][k];
        }
        _log_mel[m] = logf(sum > 1e-10f ? sum : 1e-10f);
    }

    // ── DCT-II → MFCC frame: c[i] = sum_j log_mel[j]*DCT[i][j] ─
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        float sum = 0.0f;
        for (int j = 0; j < AUDIO_N_MELS; j++) {
            sum += _log_mel[j] * DCT_MAT[i][j];
        }
        _mfcc_frame[i] = sum;
    }

    // ── Accumulate sum and sum-of-squares for online mean/std ──
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        _mfcc_sum[i]  += _mfcc_frame[i];
        _mfcc_sum2[i] += _mfcc_frame[i] * _mfcc_frame[i];
    }
    _n_frames_acc++;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_init
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_init() {
    _i2s.setDATA(I2S_DATA_PIN);
    _i2s.setBCLK(I2S_BCLK_PIN);  // WS = BCLK+1 automatically

    // begin(sampleRate, bitsPerSample, channelCount)
    // INMP441 uses 32-bit frames; 1 channel (mono, L/R tied to GND)
    if (!_i2s.begin(AUDIO_SR, 32, 1)) {
        return false;
    }
    _i2s_ready = true;
    return true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_record_and_extract
//  Records AUDIO_DURATION_S seconds, computes 26-D MFCC vector.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_record_and_extract(float* features) {
    if (!_i2s_ready) return false;

    // ── Reset accumulators ────────────────────────────────────
    memset(_mfcc_sum,  0, sizeof(_mfcc_sum));
    memset(_mfcc_sum2, 0, sizeof(_mfcc_sum2));
    _n_frames_acc = 0;

    // ── Streaming MFCC: process one HOP-sized block at a time ─
    // Each "step" reads AUDIO_HOP (128) new samples, then the
    // full 256-sample frame = [prev_half | new_half] is processed.
    static float _prev_half[AUDIO_HOP]; // kept between hops
    memset(_prev_half, 0, sizeof(_prev_half));

    // Total hops in 1 second = AUDIO_N_SAMPLES / AUDIO_HOP = 125
    int total_hops = AUDIO_N_SAMPLES / AUDIO_HOP;

    for (int hop = 0; hop < total_hops; hop++) {
        // ── Read AUDIO_HOP (128) new samples ─────────────────
        float new_half[AUDIO_HOP];
        for (int n = 0; n < AUDIO_HOP; n++) {
            int32_t raw = 0;
            // read32() returns false on error; retry once
            if (!_i2s.read32(&raw)) {
                if (!_i2s.read32(&raw)) raw = 0;
            }
            // INMP441 is left-justified: upper 24 bits are data.
            // Shift right by 8, then normalise to [-1, +1].
            int32_t s24 = raw >> 8;
            new_half[n] = (float)s24 / 8388608.0f;  // 2^23
        }

        // ── Build 256-sample frame: prev_half | new_half ─────
        // First half
        for (int n = 0; n < AUDIO_HOP; n++) _frame[n] = _prev_half[n];
        // Second half
        for (int n = 0; n < AUDIO_HOP; n++) _frame[AUDIO_HOP + n] = new_half[n];

        // ── Process the frame only after we have a full window ─
        if (hop > 0) {
            _process_frame(_frame);
        }

        // ── Advance: new_half becomes prev_half ───────────────
        memcpy(_prev_half, new_half, sizeof(new_half));
    }

    // ── Finalise: compute mean and std ───────────────────────
    int n = (_n_frames_acc > 0) ? _n_frames_acc : 1;
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        float mean = _mfcc_sum[i]  / (float)n;
        float var  = _mfcc_sum2[i] / (float)n - mean * mean;
        features[i]                 = mean;
        features[i + AUDIO_N_MFCC] = (var > 0.0f) ? sqrtf(var) : 0.0f;
    }
    return true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_measure_noise_floor
//  Read ~100 ms of audio and return RMS amplitude.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
float audio_measure_noise_floor() {
    if (!_i2s_ready) return 0.0f;

    const int n_samples = AUDIO_SR / 10;  // 1600 samples = 100 ms
    float sum_sq = 0.0f;

    for (int n = 0; n < n_samples; n++) {
        int32_t raw = 0;
        _i2s.read32(&raw);
        float s = (float)(raw >> 8) / 8388608.0f;
        sum_sq += s * s;
    }
    return sqrtf(sum_sq / (float)n_samples);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_detect_voice
//  Returns true if RMS of next AUDIO_N_FFT samples > VAD_THRESHOLD
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_detect_voice() {
    if (!_i2s_ready) return false;

    float sum_sq = 0.0f;
    for (int n = 0; n < AUDIO_N_FFT; n++) {
        int32_t raw = 0;
        _i2s.read32(&raw);
        float s = (float)(raw >> 8) / 8388608.0f;
        sum_sq += s * s;
    }
    float rms = sqrtf(sum_sq / (float)AUDIO_N_FFT);
    return (rms >= VAD_THRESHOLD);
}
