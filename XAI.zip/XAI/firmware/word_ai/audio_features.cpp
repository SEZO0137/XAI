// ============================================================
//  audio_features.cpp — INMP441 I2S + MFCC Feature Extraction
//  Word AI  |  Seeed XIAO RP2040
//
//  Fixed for arduino-pico >= 4.x  (Earle Philhower board pkg)
//
//  I2S API changes in this board package version:
//    OLD (broken): _i2s.begin(sampleRate, bits, channels)
//    NEW (correct): _i2s.begin(sampleRate)
//
//    OLD (broken): _i2s.read32(&raw)          [1 pointer]
//    NEW (correct): _i2s.read32(&left, &right) [2 pointers]
//
//  INMP441 mic wiring note:
//    L/R pin tied to GND → audio data appears on LEFT channel.
//    So we call read32(&l, &r) and use l, discard r.
// ============================================================

#include "audio_features.h"
#include "audio_constants.h"
#include <math.h>
#include <string.h>

// ── I2S object (INPUT = receive from microphone) ─────────────
static I2S  _i2s(INPUT);
static bool _i2s_ready = false;

// ── Static working buffers (avoid stack overflow on RP2040) ──
static float _frame[AUDIO_N_FFT];
static float _fft_re[AUDIO_N_FFT];
static float _fft_im[AUDIO_N_FFT];
static float _power[AUDIO_N_BINS];
static float _log_mel[AUDIO_N_MELS];
static float _mfcc_frame[AUDIO_N_MFCC];
static float _mfcc_sum[AUDIO_N_MFCC];
static float _mfcc_sum2[AUDIO_N_MFCC];
static int   _n_frames_acc;

// ── Read one normalised float sample from INMP441 ────────────
//  INMP441 is left-justified 24-bit in a 32-bit I2S frame.
//  Step 1: read32(&l, &r)  — both channels are always read
//  Step 2: use l (left channel, INMP441 L/R=GND)
//  Step 3: shift right 8 to get signed 24-bit integer
//  Step 4: divide by 2^23 (8388608) to get [-1.0 .. +1.0]
static inline float _read_sample() {
    int32_t l = 0, r = 0;
    _i2s.read32(&l, &r);
    return (float)(l >> 8) / 8388608.0f;
}

// ── Bit-reversal for radix-2 FFT ─────────────────────────────
static void _bit_reverse(float* re, float* im, int n) {
    int j = 0;
    for (int i = 1; i < n; i++) {
        int bit = n >> 1;
        for (; j & bit; bit >>= 1) j ^= bit;
        j ^= bit;
        if (i < j) {
            float tr = re[i]; re[i] = re[j]; re[j] = tr;
            float ti = im[i]; im[i] = im[j]; im[j] = ti;
        }
    }
}

// ── In-place radix-2 Cooley-Tukey FFT (N = power of 2) ──────
static void _fft(float* re, float* im, int n) {
    _bit_reverse(re, im, n);
    for (int len = 2; len <= n; len <<= 1) {
        float ang = -2.0f * (float)M_PI / (float)len;
        float wRe = cosf(ang), wIm = sinf(ang);
        for (int i = 0; i < n; i += len) {
            float curRe = 1.0f, curIm = 0.0f;
            int   half  = len >> 1;
            for (int j = 0; j < half; j++) {
                float uRe = re[i+j],    uIm = im[i+j];
                float vRe = re[i+j+half]*curRe - im[i+j+half]*curIm;
                float vIm = re[i+j+half]*curIm + im[i+j+half]*curRe;
                re[i+j]      = uRe + vRe;  im[i+j]      = uIm + vIm;
                re[i+j+half] = uRe - vRe;  im[i+j+half] = uIm - vIm;
                float t = curRe*wRe - curIm*wIm;
                curIm   = curRe*wIm + curIm*wRe;
                curRe   = t;
            }
        }
    }
}

// ── Process one 256-sample frame, update MFCC accumulators ───
static void _process_frame(const float* frame) {
    // Hamming window
    for (int n = 0; n < AUDIO_N_FFT; n++) {
        _fft_re[n] = frame[n] * HAMMING_WIN[n];
        _fft_im[n] = 0.0f;
    }
    // FFT
    _fft(_fft_re, _fft_im, AUDIO_N_FFT);
    // Power spectrum |X[k]|² / N
    for (int k = 0; k < AUDIO_N_BINS; k++) {
        _power[k] = (_fft_re[k]*_fft_re[k] + _fft_im[k]*_fft_im[k])
                    / (float)AUDIO_N_FFT;
    }
    // Mel filterbank + log
    for (int m = 0; m < AUDIO_N_MELS; m++) {
        float s = 0.0f;
        for (int k = 0; k < AUDIO_N_BINS; k++) s += _power[k] * MEL_FB[m][k];
        _log_mel[m] = logf(s > 1e-10f ? s : 1e-10f);
    }
    // DCT-II → MFCC
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        float s = 0.0f;
        for (int j = 0; j < AUDIO_N_MELS; j++) s += _log_mel[j] * DCT_MAT[i][j];
        _mfcc_frame[i] = s;
    }
    // Online accumulate
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        _mfcc_sum[i]  += _mfcc_frame[i];
        _mfcc_sum2[i] += _mfcc_frame[i] * _mfcc_frame[i];
    }
    _n_frames_acc++;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_init() — call once in setup()
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_init() {
    _i2s.setDATA(I2S_DATA_PIN);   // INMP441 SD  → D10 (GPIO4)
    _i2s.setBCLK(I2S_BCLK_PIN);  // INMP441 SCK → D8  (GPIO2)
                                   // WS is SCK+1 → D9 (GPIO3) automatically

    // ── FIX: begin() takes ONE argument in arduino-pico v4/v5 ─
    // The library sets 32-bit stereo mode internally.
    // No need to pass bit-depth or channel count.
    if (!_i2s.begin(AUDIO_SR)) {
        return false;
    }
    _i2s_ready = true;
    return true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_record_and_extract() — 1 second → 26-D MFCC vector
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_record_and_extract(float* features) {
    if (!_i2s_ready) return false;

    memset(_mfcc_sum,  0, sizeof(_mfcc_sum));
    memset(_mfcc_sum2, 0, sizeof(_mfcc_sum2));
    _n_frames_acc = 0;

    static float _prev[AUDIO_HOP];
    memset(_prev, 0, sizeof(_prev));

    int total_hops = AUDIO_N_SAMPLES / AUDIO_HOP;  // 16000/128 = 125

    for (int hop = 0; hop < total_hops; hop++) {
        // Read 128 new samples
        float cur[AUDIO_HOP];
        for (int n = 0; n < AUDIO_HOP; n++) cur[n] = _read_sample();

        // Assemble 256-sample overlapping frame
        for (int n = 0; n < AUDIO_HOP; n++) {
            _frame[n]             = _prev[n];
            _frame[AUDIO_HOP + n] = cur[n];
        }
        if (hop > 0) _process_frame(_frame);  // skip first (half-zero) frame
        memcpy(_prev, cur, sizeof(cur));
    }

    // Finalise: mean and std from accumulators
    int nf = _n_frames_acc > 0 ? _n_frames_acc : 1;
    for (int i = 0; i < AUDIO_N_MFCC; i++) {
        float mean = _mfcc_sum[i] / (float)nf;
        float var  = _mfcc_sum2[i] / (float)nf - mean * mean;
        features[i]                 = mean;
        features[i + AUDIO_N_MFCC] = (var > 0.0f) ? sqrtf(var) : 0.0f;
    }
    return true;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_measure_noise_floor() — 100 ms RMS
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
float audio_measure_noise_floor() {
    if (!_i2s_ready) return 0.0f;
    float sq = 0.0f;
    int   ns = AUDIO_SR / 10;  // 1600 samples
    for (int n = 0; n < ns; n++) { float s = _read_sample(); sq += s*s; }
    return sqrtf(sq / (float)ns);
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  audio_detect_voice() — true when RMS of 256 samples > threshold
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
bool audio_detect_voice() {
    if (!_i2s_ready) return false;
    float sq = 0.0f;
    for (int n = 0; n < AUDIO_N_FFT; n++) { float s = _read_sample(); sq += s*s; }
    return (sqrtf(sq / (float)AUDIO_N_FFT) >= VAD_THRESHOLD);
}
