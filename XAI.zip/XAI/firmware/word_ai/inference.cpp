// ============================================================
//  inference.cpp — sklearn MLP Pipeline Inference
//  Word AI  |  Seeed XIAO RP2040
// ============================================================
//
//  Performs exactly the same computation as:
//    sklearn.pipeline.Pipeline([
//      ('sc',  StandardScaler()),
//      ('clf', MLPClassifier(hidden_layer_sizes=(64,32), activation='relu'))
//    ])
//
//  All weight arrays in model_data.h use the INF_ prefix
//  to avoid conflicts with the RL network in reinforcement.h
//  (which declares NN_W0, NN_b0, NN_W1, NN_b1 for its own use).
// ============================================================

#include "inference.h"
#include "model_data.h"
#include <math.h>
#include <string.h>

static inline float _relu(float x) { return x > 0.0f ? x : 0.0f; }

static void _softmax(float* v, int n) {
    float mx = v[0];
    for (int i = 1; i < n; i++) if (v[i] > mx) mx = v[i];
    float s = 0.0f;
    for (int i = 0; i < n; i++) { v[i] = expf(v[i] - mx); s += v[i]; }
    if (s < 1e-12f) s = 1e-12f;
    for (int i = 0; i < n; i++) v[i] /= s;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  inference_run
//  features: float[26] from audio_record_and_extract()
//  result:   filled with class_idx, class_id, confidence, probs[]
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void inference_run(const float* features, InferenceResult* result) {
    int nc = N_CLASSES;
    if (nc > MAX_CLASSES) nc = MAX_CLASSES;

    // ── Step 1: StandardScaler ────────────────────────────────
    // Uses INF_SCALER_MEAN and INF_SCALER_SCALE from model_data.h
    float scaled[INPUT_DIM];
    for (int i = 0; i < INPUT_DIM; i++) {
        float sc = INF_SCALER_SCALE[i] > 1e-8f ? INF_SCALER_SCALE[i] : 1e-8f;
        scaled[i] = (features[i] - INF_SCALER_MEAN[i]) / sc;
    }

    // ── Step 2: Dense(64, ReLU) ───────────────────────────────
    // h1[j] = relu( sum_i(scaled[i] * INF_W0[i][j]) + INF_b0[j] )
    float h1[64];
    for (int j = 0; j < 64; j++) {
        float sum = INF_b0[j];
        for (int i = 0; i < INPUT_DIM; i++) sum += scaled[i] * INF_W0[i][j];
        h1[j] = _relu(sum);
    }

    // ── Step 3: Dense(32, ReLU) ───────────────────────────────
    // h2[k] = relu( sum_j(h1[j] * INF_W1[j][k]) + INF_b1[k] )
    float h2[32];
    for (int k = 0; k < 32; k++) {
        float sum = INF_b1[k];
        for (int j = 0; j < 64; j++) sum += h1[j] * INF_W1[j][k];
        h2[k] = _relu(sum);
    }

    // ── Step 4: Dense(N, Softmax) ─────────────────────────────
    // out[c] = sum_k(h2[k] * INF_W2[k][c]) + INF_b2[c]
    float out[MAX_CLASSES];
    memset(out, 0, sizeof(out));
    for (int c = 0; c < nc; c++) {
        float sum = INF_b2[c];
        for (int k = 0; k < 32; k++) sum += h2[k] * INF_W2[k][c];
        out[c] = sum;
    }
    _softmax(out, nc);

    // ── Step 5: Argmax ────────────────────────────────────────
    int   best_idx  = 0;
    float best_prob = out[0];
    for (int c = 1; c < nc; c++) {
        if (out[c] > best_prob) { best_prob = out[c]; best_idx = c; }
    }

    // ── Fill result ───────────────────────────────────────────
    result->class_idx  = best_idx;
    result->class_id   = (best_idx < N_CLASSES) ? CLASS_IDS[best_idx] : -1;
    result->confidence = best_prob;
    for (int c = 0; c < nc;          c++) result->probs[c] = out[c];
    for (int c = nc; c < MAX_CLASSES; c++) result->probs[c] = 0.0f;

    // ── BGN filter: class_id == 0 is Background Noise ────────
    // BGN is always trained as class 0 so the model can distinguish
    // silence/noise from real speech.  The firmware never acts on it —
    // mark it as "no word detected" by setting class_id to -1.
    // test_ui.py on the PC still shows the BGN probability bar.
    if (result->class_id == 0) {
        result->class_id = -1;  // tells word_ai.ino: nothing heard
    }
}
