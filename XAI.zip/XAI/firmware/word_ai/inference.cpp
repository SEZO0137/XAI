// ============================================================
//  inference.cpp — sklearn MLP Pipeline Inference
//  Word AI  |  Seeed XIAO RP2040
// ============================================================
//
//  Implements exactly:
//    sklearn.pipeline.Pipeline([
//      ('sc',  StandardScaler()),
//      ('clf', MLPClassifier(hidden_layer_sizes=(64,32), activation='relu'))
//    ])
//  using raw C float arithmetic on weight arrays from model_data.h.
//
//  The manual inference matches sklearn predict_proba() to within
//  ~1e-7 (verified in Python before generating model_data.h).
// ============================================================

#include "inference.h"
#include "model_data.h"   // SCALER_MEAN, SCALER_SCALE, NN_W*, NN_b*, N_CLASSES, INPUT_DIM
#include <math.h>
#include <string.h>

// ── Clamped ReLU ─────────────────────────────────────────────
static inline float _relu(float x) {
    return x > 0.0f ? x : 0.0f;
}

// ── Numerically stable softmax (in-place) ────────────────────
static void _softmax(float* v, int n) {
    float mx = v[0];
    for (int i = 1; i < n; i++) if (v[i] > mx) mx = v[i];
    float s = 0.0f;
    for (int i = 0; i < n; i++) { v[i] = expf(v[i] - mx); s += v[i]; }
    if (s < 1e-12f) s = 1e-12f;
    for (int i = 0; i < n; i++) v[i] /= s;
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  inference_run
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
void inference_run(const float* features, InferenceResult* result) {
    int nc = N_CLASSES;
    if (nc > MAX_CLASSES) nc = MAX_CLASSES;  // compile-time safety cap

    // ── Step 1: StandardScaler ────────────────────────────────
    // scaled[i] = (features[i] - SCALER_MEAN[i]) / SCALER_SCALE[i]
    // SCALER_SCALE is sklearn's .scale_ attribute (std dev of training set).
    // Default placeholder: MEAN=0, SCALE=1 → identity transform.
    float scaled[INPUT_DIM];
    for (int i = 0; i < INPUT_DIM; i++) {
        float sc = SCALER_SCALE[i] > 1e-8f ? SCALER_SCALE[i] : 1e-8f;
        scaled[i] = (features[i] - SCALER_MEAN[i]) / sc;
    }

    // ── Step 2: Dense layer 0 — relu(W0^T @ scaled + b0) ─────
    // NN_W0 shape: [INPUT_DIM][64]  →  h1[j] = relu(Σ scaled[i]*W0[i][j] + b0[j])
    float h1[64];
    for (int j = 0; j < 64; j++) {
        float sum = NN_b0[j];
        for (int i = 0; i < INPUT_DIM; i++) {
            sum += scaled[i] * NN_W0[i][j];
        }
        h1[j] = _relu(sum);
    }

    // ── Step 3: Dense layer 1 — relu(W1^T @ h1 + b1) ─────────
    // NN_W1 shape: [64][32]  →  h2[k] = relu(Σ h1[j]*W1[j][k] + b1[k])
    float h2[32];
    for (int k = 0; k < 32; k++) {
        float sum = NN_b1[k];
        for (int j = 0; j < 64; j++) {
            sum += h1[j] * NN_W1[j][k];
        }
        h2[k] = _relu(sum);
    }

    // ── Step 4: Output layer — softmax(W2^T @ h2 + b2) ───────
    // NN_W2 shape: [32][N_CLASSES]  →  out[c] = Σ h2[k]*W2[k][c] + b2[c]
    float out[MAX_CLASSES];
    memset(out, 0, sizeof(out));
    for (int c = 0; c < nc; c++) {
        float sum = NN_b2[c];
        for (int k = 0; k < 32; k++) {
            sum += h2[k] * NN_W2[k][c];
        }
        out[c] = sum;  // pre-softmax logit
    }
    _softmax(out, nc);

    // ── Step 5: Argmax ────────────────────────────────────────
    int   best_idx  = 0;
    float best_prob = out[0];
    for (int c = 1; c < nc; c++) {
        if (out[c] > best_prob) { best_prob = out[c]; best_idx = c; }
    }

    // ── Fill result struct ────────────────────────────────────
    result->class_idx  = best_idx;
    result->class_id   = (best_idx < N_CLASSES) ? CLASS_IDS[best_idx] : -1;
    result->confidence = best_prob;
    for (int c = 0; c < nc;          c++) result->probs[c] = out[c];
    for (int c = nc; c < MAX_CLASSES; c++) result->probs[c] = 0.0f;
}
