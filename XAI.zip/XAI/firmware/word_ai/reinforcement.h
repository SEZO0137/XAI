// ============================================================
//  reinforcement.h — Q-Table + Artificial Neuron Matrix RL
//  Word AI  |  Seeed XIAO RP2040
// ============================================================
//
//  Implements reinforcement learning using:
//    1. Q-TABLE  — tabular Q-learning (state × action)
//    2. NEURAL MATRIX — fully-connected network stored as raw
//       2-D float matrices (no OOP, strict matrix arithmetic).
//
//  The combined Q-value used for action selection is:
//      Q_combined(s,a) = Q_TABLE[s][a] * WT + Q_NN(s,a) * (1-WT)
//
//  States  = last recognised word index (0 … VOCAB_SIZE-1)
//            plus a "silence / start" state at index VOCAB_SIZE.
//  Actions = word indices to emit (0 … VOCAB_SIZE-1)
//            plus a "stop speaking" action at index VOCAB_SIZE.
//
//  Training:
//    • Single tap  → reward  = +1.0
//    • Double tap  → reward  = +0.0  (no reward / neutral)
//    • TD target   = reward + GAMMA * max_a Q(s', a)
//    • Q-table update    : Q[s][a] += ALPHA * (target - Q[s][a])
//    • Neural update     : one gradient step per second
//                          + one gradient step per feedback event
//
//  Serial CSV dump (on 10-second button hold):
//    ##META## <json>
//    ##QTABLE_START##
//    Q[0][0], Q[0][1], ..., Q[0][N_ACTIONS-1]
//    ...
//    ##QTABLE_END##
//    ##WEIGHTS_START##
//    ##LAYER## 0
//    b0, W[0][0], W[0][1], ..., W[0][IN-1]  ← output neuron 0
//    ...
//    ##LAYER## 1
//    ...
//    ##WEIGHTS_END##
// ============================================================

#pragma once
#ifndef REINFORCEMENT_H
#define REINFORCEMENT_H

#include <Arduino.h>

// ── Vocabulary / action space ─────────────────────────────────
#define VOCAB_SIZE   30          // number of recognisable words
#define N_STATES    (VOCAB_SIZE + 1)   // word states + silence
#define N_ACTIONS   (VOCAB_SIZE + 1)   // word actions + "stop"
#define STOP_ACTION  VOCAB_SIZE        // index of "stop" action
#define SILENCE_STATE VOCAB_SIZE       // index of silence state

// ── RL hyper-parameters ───────────────────────────────────────
#define RL_ALPHA     0.15f    // Q-table learning rate
#define RL_GAMMA     0.90f    // discount factor
#define RL_EPSILON   0.15f    // epsilon-greedy exploration
#define NN_LR        0.005f   // neural network learning rate
#define Q_NN_WEIGHT  0.35f    // weight of neural Q vs table Q
#define Q_LOW_THRESH 0.05f    // below this → jumble words

// ── Neural matrix dimensions ──────────────────────────────────
// Input  : one-hot(state)  →  N_STATES neurons
// Hidden : HIDDEN_SIZE neurons
// Output : N_ACTIONS neurons  (Q-value estimates per action)
#define NN_INPUT   N_STATES    // 31
#define NN_HIDDEN  16          // hidden layer width
#define NN_OUTPUT  N_ACTIONS   // 31

// ── Sentence buffers ──────────────────────────────────────────
#define MAX_SENTENCE_LEN  8    // maximum words in heard sentence
#define MAX_RESPONSE_LEN  5    // maximum words in AI response

// ── Vocabulary words ─────────────────────────────────────────
extern const char* const VOCAB[VOCAB_SIZE];

// The user-facing integer IDs for each vocabulary word
// VOCAB_IDS[i] is the external ID corresponding to index i.
extern const int VOCAB_IDS[VOCAB_SIZE];


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  RL State (global, accessed via functions only)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

// Q-table: Q_TABLE[state][action]
extern float Q_TABLE[N_STATES][N_ACTIONS];

// Neural weight matrices and bias vectors
// Layer 0: NN_INPUT  → NN_HIDDEN
extern float NN_W0[NN_INPUT][NN_HIDDEN];   // weight matrix
extern float NN_b0[NN_HIDDEN];             // bias vector
// Layer 1: NN_HIDDEN → NN_OUTPUT
extern float NN_W1[NN_HIDDEN][NN_OUTPUT];  // weight matrix
extern float NN_b1[NN_OUTPUT];             // bias vector

// Last heard sentence (word indices, -1 = empty)
extern int   SENTENCE[MAX_SENTENCE_LEN];
extern int   SENTENCE_LEN;

// Last AI response (word indices, -1 = empty)
extern int   RESPONSE[MAX_RESPONSE_LEN];
extern int   RESPONSE_LEN;

// Last state and action for TD update
extern int   RL_LAST_STATE;
extern int   RL_LAST_ACTION;


// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
//  Public API
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

/** Initialise Q-table, neural matrices, and sentence buffers. */
void rl_init();

/**
 * Decide the AI's next response word given current state s.
 * Uses epsilon-greedy combined (table + neural) policy.
 * @return action index (word index or STOP_ACTION)
 */
int rl_select_action(int state);

/**
 * Build a full response sentence for the given heard sentence.
 * Fills RESPONSE[] and RESPONSE_LEN.
 * If confidence is too low, words are jumbled randomly.
 * @param heard_indices  array of word indices in the heard sentence
 * @param heard_len      number of words heard
 */
void rl_build_response(const int* heard_indices, int heard_len);

/**
 * Apply a TD update to both Q-table and neural network.
 * Call this after receiving user feedback.
 * @param state   the state at the time of the response
 * @param action  the action that was taken
 * @param reward  +1.0 (good) or 0.0 (not good)
 * @param next_state  the state after action (SILENCE_STATE if end)
 */
void rl_update(int state, int action, float reward, int next_state);

/**
 * Periodic neural network gradient step (call every second).
 * Replays the last (s, a, r, s') experience to consolidate learning.
 */
void rl_periodic_update();

/** Add a detected word index to the current sentence buffer. */
void sentence_add_word(int word_idx);

/** Clear the sentence buffer. */
void sentence_clear();

/** Convert sentence buffer to a space-separated string (OLED display). */
void sentence_to_str(char* buf, int buf_len);

/** Convert response buffer to a space-separated string (OLED display). */
void response_to_str(char* buf, int buf_len);

/**
 * Emit full CSV dump over Serial (called on 10-second button hold).
 * Format documented in reinforcement.h header comment.
 */
void rl_serial_dump(int n_classes, int input_dim,
                    const int* class_ids, const char* const* class_names);

/** Return external word ID for a vocab index (-1 if invalid). */
int vocab_id(int idx);

/** Return vocab index for an external word ID (-1 if not found). */
int vocab_index(int id);

/** Return word string for a vocab index ("?" if invalid). */
const char* vocab_word(int idx);

#endif // REINFORCEMENT_H
