// ============================================================
//  audio_features.h — INMP441 I2S + MFCC Feature Extraction
//  Word AI  |  Seeed XIAO RP2040
// ============================================================
//
//  INMP441 Wiring (XIAO RP2040):
//    VDD  → 3.3 V
//    GND  → GND
//    SD   → D10 / GPIO 4   (I2S data)
//    WS   → D9  / GPIO 3   (I2S word-select / LRCLK)
//    SCK  → D8  / GPIO 2   (I2S bit-clock)
//    L/R  → GND             (left-channel select → left-justified)
//
//  The library used is the I2S class from the Arduino-Pico core
//  (Earle Philhower III). BCLK pin is set to I2S_BCLK_PIN; the
//  WS/LRCLK pin is automatically BCLK_PIN + 1 (GPIO 3).
//
//  Audio format:
//    • Sample rate  : 16 000 Hz
//    • Bit depth    : 32-bit reads (INMP441 uses upper 24 bits)
//    • Channels     : 1 (mono, left channel)
//
//  Feature extraction (must exactly match recorder_ui.py):
//    • Frame    : 256 samples (16 ms)
//    • Hop      : 128 samples ( 8 ms)
//    • Mel bins : 26
//    • MFCC     : 13
//    • Output   : 26-D float32  [ mean(13) ‖ std(13) ]
//    • Streaming: accumulates frames online → O(256) audio RAM
// ============================================================

#pragma once
#ifndef AUDIO_FEATURES_H
#define AUDIO_FEATURES_H

#include <Arduino.h>
#include <I2S.h>

// ── I2S pin assignments ──────────────────────────────────────
// Change these to match your specific wiring.
// WS (LRCLK) = I2S_BCLK_PIN + 1  (set automatically by I2S library)
#define I2S_DATA_PIN   4    // GPIO 4 = D10 on XIAO RP2040
#define I2S_BCLK_PIN   2    // GPIO 2 = D8  (WS will be GPIO 3)

// ── Audio constants ──────────────────────────────────────────
#define AUDIO_SR          16000
#define AUDIO_DURATION_S  1         // seconds per recording
#define AUDIO_N_SAMPLES   (AUDIO_SR * AUDIO_DURATION_S)  // 16000

#define AUDIO_N_FFT      256
#define AUDIO_N_BINS     129        // N_FFT/2 + 1
#define AUDIO_N_MELS      26
#define AUDIO_N_MFCC      13
#define AUDIO_HOP        128
#define AUDIO_INPUT_DIM   26        // mean(13) + std(13)

// Number of frames in 1 second of audio with 50 % overlap
// = (AUDIO_N_SAMPLES - AUDIO_N_FFT) / AUDIO_HOP + 1 = ~124
#define AUDIO_N_FRAMES   ((AUDIO_N_SAMPLES - AUDIO_N_FFT) / AUDIO_HOP + 1)

// ── VAD threshold (RMS energy, raw 24-bit scale) ─────────────
// INMP441 full scale ≈ 2^23 = 8388608.
// Quiet room background ≈ 0.001 relative → 8388 raw units.
// Speech onset ≈ 0.01 relative  → 83886 raw units.
#define VAD_THRESHOLD    0.010f     // normalised RMS threshold

// ── Public API ───────────────────────────────────────────────

/**
 * Initialise the I2S peripheral and configure the INMP441 pins.
 * Call once in setup() before any audio functions.
 * Returns true on success.
 */
bool audio_init();

/**
 * Record exactly AUDIO_DURATION_S seconds and compute the 26-D
 * MFCC feature vector (mean‖std).
 *
 * @param features  Output buffer — caller must provide float[26].
 * @returns         true on success, false if I2S read fails.
 */
bool audio_record_and_extract(float* features);

/**
 * Measure background RMS for ~100 ms and return normalised value.
 * Can be called once in setup() to set a dynamic VAD threshold.
 */
float audio_measure_noise_floor();

/**
 * Non-blocking voice-activity detection.
 * Returns true if speech energy (measured over AUDIO_N_FFT samples)
 * exceeds VAD_THRESHOLD.
 */
bool audio_detect_voice();

#endif // AUDIO_FEATURES_H
